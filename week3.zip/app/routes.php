<?php
// Routes

$app->get('/', 'App\Controller\HomeController:home')
    ->setName('homepage');
	
$app->post('/da', 'App\Controller\HomeController:da')
    ->setName('da');

$app->get('/post/{id}', 'App\Controller\HomeController:viewPost')
    ->setName('view_post');

$app->post('/da/forgot_sendmail', 'App\Controller\UCSDController:forgot_sendMail')
    ->setName('forgot_sendmail');

$app->get('/da/signup', 'App\Controller\UCSDController:signUp')
    ->setName('signup');

$app->post('/da/signup2', 'App\Controller\UCSDController:emailcheck')
    ->setName('signup2');

$app->post('/da/signup3', 'App\Controller\UCSDController:signup_success')
    ->setName('signup3');


$app->get('/da/active', 'App\Controller\UCSDController:activationcheck')
    ->setName('activationcheck');
	
$app->post('/da/deregistration', 'App\Controller\UCSDController:deregistration')
    ->setName('deregistration');

$app->post('/da/deregistration2', 'App\Controller\UCSDController:deregistration_check')
    ->setName('deregistration_check');

$app->post('/da/signin', 'App\Controller\UCSDController:login')
    ->setName('login');

//�¹谡 ����
$app->post('/da/signout', 'App\Controller\UCSDController:signout')
    ->setName('signout');

$app->get('/da/signin', 'App\Controller\UCSDController:login')
    ->setName('login');

$app->post('/da/signin2', 'App\Controller\UCSDController:logincheck')
    ->setName('logincheck');

$app->get('/da/lostpw', 'App\Controller\UCSDController:lostpw')
    ->setName('lostpw');

$app->get('/da/forgotchangepw', 'App\Controller\UCSDController:forgotchange_pw')
    ->setName('forgotchange_pw');

$app->get('/da/forgotchangepw2', 'App\Controller\UCSDController:forgotchange_pw2')
    ->setName('forgotchange_pw2');
	
$app->post('/da/changepw', 'App\Controller\UCSDController:changepw')
    ->setName('changepw');
	
$app->post('/da/checkedchangepw', 'App\Controller\UCSDController:changepw2')
    ->setName('changepw2');
	
$app->get('/da/process', 'App\Controller\UCSDController:handleSignUp')
    ->setName('process');

$app->get('/da/profile', 'App\Controller\UCSDController:profile')
    ->setName('profile');
	
$app->get('/da/hr', 'App\Controller\UCSDController:heartrate')
    ->setName('heartrate');
	
$app->get('/da/temp', 'App\Controller\UCSDController:temp')
    ->setName('temp');

$app->get('/da/air', 'App\Controller\UCSDController:air')
    ->setName('air');
