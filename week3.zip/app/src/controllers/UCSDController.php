<?php
namespace App\Controller;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PDO;

final class UCSDController extends BaseController
{


	public function lostpw(Request $request, Response $response, $args) {
        $this->view->render($response, 'pages-recover-pw.phtml');
        return $response;
    }



     public function forgot_sendMail(Request $request, Response $response, $args) {

		$e_mail = $_POST['email'];
		$message = NULL;


		
		
		if($e_mail == '')
		{echo 'aaaa';

		$this->view->render($response, 'pages-recover-pw.phtml',['message'=>$message]);
		}
		else{
			$connect = new PDO('mysql:host=localhost; dbname=dailyassi','root','12345678');
			$statement = $connect->prepare("select * from users where e_mail=?");
			$statement->execute(array($e_mail));
			$row = $statement->fetch();

			

			if($row['fname'])
			{
				echo "a";

				
						// $this->getApp()->contentType('text/html');
			  $mail = new PHPMailer(true);                              // Passing `true` enables exceptions
			  try {
			  	  //Server settings
				//$mail->SMTPDebug = 2;                                 // Enable verbose debug output
				$mail->isSMTP();                                      // Set mailer to use SMTP
				$mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
				$mail->SMTPAuth = true;                               // Enable SMTP authentication
				$mail->Username = 'dailyassi19@gmail.com';                 // SMTP username
				$mail->Password = '!teamb11';                           // SMTP password
				$mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
				$mail->Port = 587;                                    // TCP port to connect to

				//Recipients
				$mail->setFrom('dailyassi19@gmail.com', 'DailyAssi');
				$mail->addAddress($e_mail, $row['fname']);     // Add a recipient
				//$mail->addAddress('ellen@example.com');               // Name is optional
				$mail->addReplyTo('info@example.com', 'Information');
				$mail->addCC('cc@example.com');
				$mail->addBCC('bcc@example.com');

				//Attachments
				//$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
				//$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

				//Content
				$mail->isHTML(true);                                  // Set email format to HTML
				$mail->Subject = 'Here is the subject';
				$mail->Body    = 'Thanks for signing up!
				Your account has been created, you can login with the following credentials after you have activated your account by pressing the url below.<br/>

 
				------------------------<br/>
				Username: '.$e_mail.'<br/>
				------------------------<br/>
 <br/>
				Please click this link to activate your account:
				http://192.168.33.99/da/forgotchangepw?email='.$e_mail.'&hash='.$row['hash'].'';
				$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

				$mail->send();
				echo 'Message has been sent';
			  }
				
				  catch (Exception $e) {
					echo 'Message could not be sent.';
					echo 'Mailer Error: ' . $mail->ErrorInfo;
				   }
				   
				   
				//$this->render("index/mail.phtml");
				$this->view->render($response, 'home.phtml');
				return $response;

			
			}
			else{
				echo "<script>alert(\"email is not exist\");</script>";
				$this->view->render($response, 'pages-recover-pw.phtml');
			}

		}

      return $response;
	 }

	 public function forgotchange_pw(Request $request, Response $response, $args) {
		
		$this->view->render($response, 'forgotchange-pw.phtml');
        return $response;
    }

	public function forgotchange_pw2(Request $request, Response $response, $args) {
	
		$e_mail = $_GET['email'];
		var_dump($e_mail);

		/*
		if($newpwd == '' || $newpwd_confirm== ''){
			if($newpwd == ''){
				echo "<script>alert(\"Input your new password\");</script>";
				$this->view->render($response, 'forgotchange-pw.phtml');
			}
			else if($newpwd_confirm == ''){
				echo "<script>alert(\"Input your new password Confirmation\");</script>";
				$this->view->render($response, 'forgotchange-pw.phtml');
			}
		}

		else{
			if($newpwd != $newpwd_confirm){
				echo "<script>alert(\"Confirm your new Password\");</script>";
				$this->view->render($response, 'forgotchange-pw.phtml');
			}
			else{
				$connect = new PDO('mysql:host=localhost;dbname=dailyassi', 'root','12345678');
				$connect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				$statement = $connect->prepare("select * from users where e_mail=?");
				$statement->execute(array('.$e_mail.'));
				$row = $statement->fetch();
				$e_mail = $_GET['email'];

				

				if($row['fname']){
					$new_hash_pwd = password_hash($newpwd, PASSWORD_DEFAULT);
					$statement = $connect->prepare("UPDATE users set hash_pwd='$new_hash_pwd' WHERE e_mail=?");
					$statement->execute(array($e_mail));
					$this->view->render($response, 'pages-signin.phtml',['message'=>$message]);
					echo "<script>alert(\"Success password change\");</script>";
				}
				else{
						echo "<script>alert(\"Incorrect information\");</script>";
						$this->view->render($response, 'pages-signin.phtml',['message'=>$message]);
				}
			
			}
		}
		return response;*/
    }



    public function signup(Request $request, Response $response, $args) {
       
		$this->view->render($response, 'pages-signup.phtml');
        return $response;
		
	
 

    }

	public function emailcheck(Request $request, Response $response, $args) {
		$e_mail = $_POST['email'];

		if($e_mail == ''){
			echo "<script>alert(\"Input your E_mail Address\");</script>";
			$this->view->render($response, 'pages-signup.phtml');			
		}
		else{
			$connect = new PDO('mysql:host=localhost;dbname=dailyassi', 'root','12345678');
			$connect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);			
			$statement = $connect->prepare("select * from users where e_mail=?");
			$statement->execute(array($e_mail));
			$count = $statement->rowCount();

			if($count>0)
			{
				echo "<script>alert(\"Input email is already exist\");</script>";
				$this->view->render($response,'pages-signup.phtml',['message'=>$message]);
			}
			else{
				echo "<script>alert(\"Input email is usable\");</script>";
				$this->view->render($response,'pages-signup.phtml',['message'=>$message]);
		
			}
		}

    }
	


	public function signup_success(Request $request, Response $response, $args) {
		$e_mail = $_POST['email'];
		$fname = $_POST['fname'];
		$lname = $_POST['lname'];
		$hash_pwd = $_POST['pwd'];
		$pwd_confirm = $_POST['pwd_confirm'];
		$sex = $_POST['Gender'];
		$hash = md5( rand(0,1000) );
		$admin = 0;
		$active = 0;
		
		

		
		if($e_mail == '' || $fname == '' || $lname == '' || $hash_pwd == '' || $pwd_confirm == '' || $sex == ''){
			
			if($e_mail == ''){
				echo "<script>alert(\"Input your E_mail Address\");</script>";
				$this->view->render($response, 'pages-signup.phtml');
			}
			else if($fname == ''){
				echo "<script>alert(\"Input your First Name\");</script>";
				$this->view->render($response, 'pages-signup.phtml');
			}
			else if($lname == ''){
				echo "<script>alert(\"Input your Last Name\");</script>";
				$this->view->render($response, 'pages-signup.phtml');
			}
			else if($hash_pwd == ''){
				echo "<script>alert(\"Input your Password \");</script>";
				$this->view->render($response, 'pages-signup.phtml');
			}
			else if($pwd_confirm == ''){
				echo "<script>alert(\"Input your Password Confirmation\");</script>";
				$this->view->render($response, 'pages-signup.phtml');
			}
			
			
		}
		else{
			if($hash_pwd != $pwd_confirm){
				echo "<script>alert(\"Confirm your Password\");</script>";
				$this->view->render($response, 'pages-signup.phtml');
				return $response;
			}
			
			$connect = new PDO('mysql:host=localhost;dbname=dailyassi', 'root','12345678');
			$hashed_pwd = password_hash($hash_pwd, PASSWORD_DEFAULT);
			$statement = $connect->prepare("insert into users(e_mail,fname,lname,hash_pwd,sex,hash,admin,active)values(?,?,?,?,?,?,?,?);");
			$statement->execute(array($e_mail,$fname,$lname,$hashed_pwd,$sex,$hash,$admin,$active));
			



			if($e_mail == '')
			{echo 'aaaa';

			$this->view->render($response, 'pages-recover-pw.phtml',['message'=>$message]);
			}
			else{
			$connect = new PDO('mysql:host=localhost; dbname=dailyassi','root','12345678');
			$statement = $connect->prepare("select * from users where e_mail=?");
			$statement->execute(array($e_mail));
			$row = $statement->fetch();

			

			if($row['fname'])
			{
				echo "a";

				
						// $this->getApp()->contentType('text/html');
			  $mail = new PHPMailer(true);                              // Passing `true` enables exceptions
			  try {
			  	  //Server settings
				//$mail->SMTPDebug = 2;                                 // Enable verbose debug output
				$mail->isSMTP();                                      // Set mailer to use SMTP
				$mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
				$mail->SMTPAuth = true;                               // Enable SMTP authentication
				$mail->Username = 'dailyassi19@gmail.com';                 // SMTP username
				$mail->Password = '!teamb11';                           // SMTP password
				$mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
				$mail->Port = 587;                                    // TCP port to connect to

				//Recipients
				$mail->setFrom('dailyassi19@gmail.com', 'DailyAssi');
				$mail->addAddress($e_mail, $row['fname']);     // Add a recipient
				//$mail->addAddress('ellen@example.com');               // Name is optional
				$mail->addReplyTo('info@example.com', 'Information');
				$mail->addCC('cc@example.com');
				$mail->addBCC('bcc@example.com');

				//Attachments
				//$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
				//$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

				//Content
				$mail->isHTML(true);                                  // Set email format to HTML
				$mail->Subject = 'Here is the subject';
				$mail->Body    = 'Thanks for signing up!
				Your account has been created, you can login with the following credentials after you have activated your account by pressing the url below.<br/>

 
				------------------------<br/>
				Username: '.$e_mail.'<br/>
				------------------------<br/>
 <br/>
				Please click this link to activate your account:
				http://192.168.33.99/da/active?email='.$e_mail.'&hash='.$hash.'';
				$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

				$mail->send();
				echo 'Message has been sent';
			  }
				
				  catch (Exception $e) {
					echo 'Message could not be sent.';
					echo 'Mailer Error: ' . $mail->ErrorInfo;
				   }
				   
				   
				//$this->render("index/mail.phtml");
				$this->view->render($response, 'home.phtml');
				return $response;

			
			}
			else{
				echo "<script>alert(\"email is not exist\");</script>";
				$this->view->render($response, 'pages-signup.phtml');
			}

		}



			$this->view->render($response,'pages-signin.phtml',['message'=> $message]);
			var_dump($hashed_pwd);

		
		}
		return $response;
    }
	
	public function deregistration(Request $request, Response $response, $args) {
		$this->view->render($response, 'deregistration.phtml');
        return $response;
    }
	
	public function activationcheck(Request $request, Response $response, $args) {
		
		
		$connect = new PDO('mysql:host=localhost;dbname=dailyassi', 'root','12345678');
		$connect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$statement = $connect->prepare("select * from users where e_mail=?");
		$statement->execute(array('.$e_mail.'));
		$row = $statement->fetch();

		
		$e_mail = $_GET['email'];

		var_dump($row['fname']);
		

		if(row['fname']){
		$statement = $connect->prepare("UPDATE users set active=1 WHERE e_mail=?");
		$statement->execute(array($e_mail));
		
		
		
		
		$this->view->render($response, 'activation_check.phtml');
        return $response;
		}
    }

	public function deregistration_check(Request $request, Response $response, $args) {
		$hash_pwd = $_POST['password'];
		$message = NULL;
		$user_seq_num = $_SESSION['seq_num'];

		if($hash_pwd == '')
		{
			$message = "Input your password";
			$this->view->render($response, 'deregistration.phtml',['message'=>$message]);
		}
		else{
			$connect = new PDO('mysql:host=localhost;dbname=dailyassi','root','12345678');
			$statement = $connect->prepare("select * from users where user_seq_num=?");
			$statement->execute(array($user_seq_num));
			$row = $statement->fetch();

			if($row['fname']){
				$hashed_pwd= $row['hash_pwd'];
				if(password_verify($hash_pwd,$hashed_pwd))
				{
					$statement = $connect->prepare("DELETE FROM users WHERE user_seq_num=?");
					$statement->execute(array($user_seq_num));
					$this->view->render($response,'home.phtml',['message'=>$message]);
					echo "<script>alert(\"Deregistration is success\");</script>";
				}
				else{
				$message = "Information is not correct";
				$this->view->render($response,'deregistration.phtml',['message'=>$message]);
				}
			
			}

		}

    }
	
    public function login(Request $request, Response $response, $args) {
        $this->view->render($response, 'pages-signin.phtml');
        return $response;
		
    }

	public function logincheck(Request $request, Response $response, $args) {
		var_dump($request->getParams());
       
	  
	    $e_mail = $_POST['E-mail'];
		$hash_pwd = $_POST['pwd'];
		$message = NULL;

		
		
		if($e_mail == ''||$hash_pwd == '')
		{
			$this->view->render($response, 'pages-signin.phtml',['message'=>$message]);
		}
		
		else{


			$connect = new PDO('mysql:host=localhost; dbname=dailyassi','root','12345678');
			$statement = $connect->prepare("select * from users where e_mail=?");
			$statement->execute(array($e_mail));
			$row = $statement->fetch();
			
			
			var_dump($row['user_seq_num']);
			//���� Ȱ��ȭ
			if($row['active']==0){
				echo "<script>alert(\"Activation need to verify\");</script>";
				$this->view->render($response, 'pages-signin.phtml',['message'=>$message]);
			}
			else{
			
			
				if($row['fname'])
				{
					$hashed_pwd = $row['hash_pwd'];
					if(password_verify($hash_pwd, $hashed_pwd))
					{
						$_SESSION['userName'] = $row["fname"];
						$_SESSION['seq_num'] = $row["user_seq_num"];
						$this->view->render($response, 'index.phtml');
					}
					else{
						echo "<script>alert(\"Incorrect login information\");</script>";
						$this->view->render($response, 'pages-signin.phtml',['message'=>$message]);
					}
				}
				else{
					echo "<script>alert(\"email is not exist2\");</script>";
					$this->view->render($response, 'pages-signin.phtml',['message'=>$message]);
				}
			}
		}
		return $response;
    }

	
	
	public function changepw(Request $request, Response $response, $args) {
        $this->view->render($response, 'change-pw.phtml');
        return $response;
    }
	
	public function changepw2(Request $request, Response $response, $args) {
        
		$nowpwd = $_POST['nowpassword'];
		$newpwd = $_POST['newpwd'];
		$newpwd_confirm = $_POST['newpwd_confirm'];
		$user_seq_num = $_SESSION['seq_num'];
	 
		if($nowpwd == '' || $newpwd == '' || $newpwd_confirm == ''){
			if($nowpwd == '') {
				echo "<script>alert(\"Input your now password\");</script>";
					$this->view->render($response, 'change-pw.phtml');
			}
	 
			else if($newpwd == '') {
				echo "<script>alert(\"Input your new password\");</script>";
					$this->view->render($response, 'change-pw.phtml');
			}
	 
			else if($newpwd_confirm == '') {
				echo "<script>alert(\"Input your new password Confirmation\");</script>";
					$this->view->render($response, 'change-pw.phtml');
			}
		}
		
			
		else{		
			if($newpwd != $newpwd_confirm){
				echo "<script>alert(\"Confirm your new password\");</script>";
				$this->view->render($response, 'change-pw.phtml');
			}
			else{
				$connect = new PDO('mysql:host=localhost;dbname=dailyassi', 'root','12345678');
				$connect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				$statement = $connect->prepare("select * from users where user_seq_num=?");
				$statement->execute(array($user_seq_num));
				$row = $statement->fetch();
			
		
				if($row['fname'])
					{
						$hashed_pwd = $row['hash_pwd'];
						if(password_verify($nowpwd, $hashed_pwd))
						{
							$new_hash_pwd=password_hash($newpwd, PASSWORD_DEFAULT);
							$statement = $connect->prepare("UPDATE users set hash_pwd='$new_hash_pwd' WHERE user_seq_num=?");
							$statement->execute(array($user_seq_num));
							$this->view->render($response, 'pages-signin.phtml',['message'=>$message]);
						}
						else{
							echo "<script>alert(\"Incorrect login information\");</script>";
							$this->view->render($response, 'pages-signin.phtml',['message'=>$message]);
						}
					}
			}
		}
		return response;
	}		
		

	public function profile(Request $request, Response $response, $args) {
        $this->view->render($response, 'pages-user-profile.phtml');
        return $response;
    }
	
	public function heartrate(Request $request, Response $response, $args) {
		$this->view->render($response, 'heart-rate.phtml');
        return $response;
    }
	
	public function temp(Request $request, Response $response, $args) {
		$this->view->render($response, 'temp.phtml');
        return $response;
    }
	
	public function air(Request $request, Response $response, $args) {
		$this->view->render($response, 'air.phtml');
        return $response;
    }
	
	//�¹谡 ����
	public function signout(Request $request, Response $response, $args) {
		session_destroy();
		$this->view->render($response, 'pages-signin.phtml');
        return $response;
    }

    public function handleSignUp(Request $request, Response $response, $args) {
    
     //   print_r($_POST);
//        print_r($_GET)
        echo "<br /><br>\n";
     //   var_dump($_POST);
      // your code should ... 1) check to see if email address is in database.
      
	
  $myarray = array("yourname"=>$_POST['name'], "color"=>"Green", "size"=>"large");

$account_exists = false;
if ($account_exists) 
    $this->view->render($response, 'process_bad.html');//, ['myarray'=>$myarray, 'fakevariable' =>1000, 'post' => $_POST, 'flash' => $messages]);
 else {
    $this->view->render($response, 'process_good.phtml', ['myarray'=>$myarray, 'fakevariable' =>"$1000 Million", 'post' => $_POST]);
}

    
    return $response;

    }
 }

 