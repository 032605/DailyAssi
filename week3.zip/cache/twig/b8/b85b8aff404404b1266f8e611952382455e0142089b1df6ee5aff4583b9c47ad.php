<?php

/* pages-signin.phtml */
class __TwigTemplate_ebfc1beefe767914fcc731a06927b76e0b32bb76e2e4db8748def79a89869a29 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!doctype html>
<html class=\"fixed\">
\t<head>

\t\t<!-- Basic -->
\t\t<meta charset=\"UTF-8\">

\t\t<meta name=\"keywords\" content=\"HTML5 Admin Template\" />
\t\t<meta name=\"description\" content=\"Porto Admin - Responsive HTML5 Template\">
\t\t<meta name=\"author\" content=\"okler.net\">

\t\t<!-- Mobile Metas -->
\t\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no\" />

\t\t<!-- Web Fonts  -->
\t\t<link href=\"http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light\" rel=\"stylesheet\" type=\"text/css\">

\t\t<!-- Vendor CSS -->
\t\t<link rel=\"stylesheet\" href=\"../assets/vendor/bootstrap/css/bootstrap.css\" />
\t\t<link rel=\"stylesheet\" href=\"../assets/vendor/font-awesome/css/font-awesome.css\" />
\t\t<link rel=\"stylesheet\" href=\"../assets/vendor/magnific-popup/magnific-popup.css\" />
\t\t<link rel=\"stylesheet\" href=\"../assets/vendor/bootstrap-datepicker/css/datepicker3.css\" />

\t\t<!-- Theme CSS -->
\t\t<link rel=\"stylesheet\" href=\"../assets/stylesheets/theme.css\" />

\t\t<!-- Skin CSS -->
\t\t<link rel=\"stylesheet\" href=\"../../assets/stylesheets/skins/default.css\" />

\t\t<!-- Theme Custom CSS -->
\t\t<link rel=\"stylesheet\" href=\"../assets/stylesheets/theme-custom.css\">

\t\t<!-- Head Libs -->
\t\t<script src=\"../assets/vendor/modernizr/modernizr.js\"></script>

\t</head>
\t<body>
\t\t<!-- start: page -->
\t\t<section class=\"body-sign\">
\t\t\t<div class=\"center-sign\">
\t\t\t\t
\t\t\t\t<a href=\"/\" class=\"logo pull-left\">
\t\t\t\t\t<img src=\"../assets/images/clogo.png\" height=\"80\" alt=\"Porto Admin\" />
\t\t\t\t</a>

\t\t\t\t<div class=\"panel panel-sign\">
\t\t\t\t\t<div class=\"panel-title-sign mt-xl text-right\">
\t\t\t\t\t\t<h2 class=\"title text-uppercase text-bold m-none\"><i class=\"fa fa-user mr-xs\"></i> Sign In</h2>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"panel-body\">
\t\t\t\t\t\t<form action=\"../da\" method=\"post\">
\t\t\t\t\t\t\t<div class=\"form-group mb-lg\">
\t\t\t\t\t\t\t\t<label>E-mail</label>
\t\t\t\t\t\t\t\t<div class=\"input-group input-group-icon\">
\t\t\t\t\t\t\t\t\t<input name=\"E-mail\" type=\"text\" class=\"form-control input-lg\" />
\t\t\t\t\t\t\t\t\t<span class=\"input-group-addon\">
\t\t\t\t\t\t\t\t\t\t<span class=\"icon icon-lg\">
\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-user\"></i>
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t<div class=\"form-group mb-lg\">
\t\t\t\t\t\t\t\t<div class=\"clearfix\">
\t\t\t\t\t\t\t\t\t<label class=\"pull-left\">Password</label>
\t\t\t\t\t\t\t\t\t<a href=\"../da/lostpw\" class=\"pull-right\">forgot Password?</a>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"input-group input-group-icon\">
\t\t\t\t\t\t\t\t\t<input name=\"pwd\" type=\"password\" class=\"form-control input-lg\" />
\t\t\t\t\t\t\t\t\t<span class=\"input-group-addon\">
\t\t\t\t\t\t\t\t\t\t<span class=\"icon icon-lg\">
\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-lock\"></i>
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t
\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t<div class=\"col-sm-8\">
\t\t\t\t\t\t\t\t\t<div class=\"checkbox-custom checkbox-default\">
\t\t\t\t\t\t\t\t\t\t<input id=\"RememberMe\" name=\"rememberme\" type=\"checkbox\"/>
\t\t\t\t\t\t\t\t\t\t<label for=\"RememberMe\">Remember Me</label>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-sm-4 text-right\">
\t\t\t\t\t\t\t\t\t<button type=\"submit\" class=\"btn btn-primary hidden-xs\">Sign In</button>
\t\t\t\t\t\t\t\t\t<button type=\"submit\" class=\"btn btn-primary btn-block btn-lg visible-xs mt-lg\">Sign In</button>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t
\t\t\t\t\t\t\t<span class=\"mt-lg mb-lg line-thru text-center text-uppercase\">
\t\t\t\t\t\t\t\t<span>or</span>
\t\t\t\t\t\t\t</span>

\t\t\t\t\t\t\t<div class=\"mb-xs text-center\">
\t\t\t\t\t
\t\t\t\t\t\t\t<p class=\"text-center\">Don't have an account yet? <a href=\"http://192.168.33.99/da/signup\">Sign Up!</a>
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t</form>
\t\t\t\t\t</div>
\t\t\t\t</div>

\t\t\t\t<p class=\"text-center text-muted mt-md mb-md\">&copy; Copyright 2018. All rights reserved. Template by <a href=\"https://colorlib.com\">Colorlib</a>.</p>
\t\t\t</div>
\t\t</section>
\t\t<!-- end: page -->

\t\t<!-- Vendor -->
\t\t<script src=\"../assets/vendor/jquery/jquery.js\"></script>
\t\t<script src=\"../assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js\"></script>
\t\t<script src=\"../assets/vendor/bootstrap/js/bootstrap.js\"></script>
\t\t<script src=\"../assets/vendor/nanoscroller/nanoscroller.js\"></script>
\t\t<script src=\"../assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js\"></script>
\t\t<script src=\"../assets/vendor/magnific-popup/magnific-popup.js\"></script>
\t\t<script src=\"../assets/vendor/jquery-placeholder/jquery.placeholder.js\"></script>
\t\t
\t\t<!-- Theme Base, Components and Settings -->
\t\t<script src=\"../assets/javascripts/theme.js\"></script>
\t\t
\t\t<!-- Theme Custom -->
\t\t<script src=\"../assets/javascripts/theme.custom.js\"></script>
\t\t
\t\t<!-- Theme Initialization Files -->
\t\t<script src=\"../assets/javascripts/theme.init.js\"></script>
</html>";
    }

    public function getTemplateName()
    {
        return "pages-signin.phtml";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
/* <!doctype html>*/
/* <html class="fixed">*/
/* 	<head>*/
/* */
/* 		<!-- Basic -->*/
/* 		<meta charset="UTF-8">*/
/* */
/* 		<meta name="keywords" content="HTML5 Admin Template" />*/
/* 		<meta name="description" content="Porto Admin - Responsive HTML5 Template">*/
/* 		<meta name="author" content="okler.net">*/
/* */
/* 		<!-- Mobile Metas -->*/
/* 		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />*/
/* */
/* 		<!-- Web Fonts  -->*/
/* 		<link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">*/
/* */
/* 		<!-- Vendor CSS -->*/
/* 		<link rel="stylesheet" href="../assets/vendor/bootstrap/css/bootstrap.css" />*/
/* 		<link rel="stylesheet" href="../assets/vendor/font-awesome/css/font-awesome.css" />*/
/* 		<link rel="stylesheet" href="../assets/vendor/magnific-popup/magnific-popup.css" />*/
/* 		<link rel="stylesheet" href="../assets/vendor/bootstrap-datepicker/css/datepicker3.css" />*/
/* */
/* 		<!-- Theme CSS -->*/
/* 		<link rel="stylesheet" href="../assets/stylesheets/theme.css" />*/
/* */
/* 		<!-- Skin CSS -->*/
/* 		<link rel="stylesheet" href="../../assets/stylesheets/skins/default.css" />*/
/* */
/* 		<!-- Theme Custom CSS -->*/
/* 		<link rel="stylesheet" href="../assets/stylesheets/theme-custom.css">*/
/* */
/* 		<!-- Head Libs -->*/
/* 		<script src="../assets/vendor/modernizr/modernizr.js"></script>*/
/* */
/* 	</head>*/
/* 	<body>*/
/* 		<!-- start: page -->*/
/* 		<section class="body-sign">*/
/* 			<div class="center-sign">*/
/* 				*/
/* 				<a href="/" class="logo pull-left">*/
/* 					<img src="../assets/images/clogo.png" height="80" alt="Porto Admin" />*/
/* 				</a>*/
/* */
/* 				<div class="panel panel-sign">*/
/* 					<div class="panel-title-sign mt-xl text-right">*/
/* 						<h2 class="title text-uppercase text-bold m-none"><i class="fa fa-user mr-xs"></i> Sign In</h2>*/
/* 					</div>*/
/* 					<div class="panel-body">*/
/* 						<form action="../da" method="post">*/
/* 							<div class="form-group mb-lg">*/
/* 								<label>E-mail</label>*/
/* 								<div class="input-group input-group-icon">*/
/* 									<input name="E-mail" type="text" class="form-control input-lg" />*/
/* 									<span class="input-group-addon">*/
/* 										<span class="icon icon-lg">*/
/* 											<i class="fa fa-user"></i>*/
/* 										</span>*/
/* 									</span>*/
/* 								</div>*/
/* 							</div>*/
/* */
/* 							<div class="form-group mb-lg">*/
/* 								<div class="clearfix">*/
/* 									<label class="pull-left">Password</label>*/
/* 									<a href="../da/lostpw" class="pull-right">forgot Password?</a>*/
/* 								</div>*/
/* 								<div class="input-group input-group-icon">*/
/* 									<input name="pwd" type="password" class="form-control input-lg" />*/
/* 									<span class="input-group-addon">*/
/* 										<span class="icon icon-lg">*/
/* 											<i class="fa fa-lock"></i>*/
/* 										</span>*/
/* 									</span>*/
/* 								</div>*/
/* 							</div>*/
/* 						*/
/* 							<div class="row">*/
/* 								<div class="col-sm-8">*/
/* 									<div class="checkbox-custom checkbox-default">*/
/* 										<input id="RememberMe" name="rememberme" type="checkbox"/>*/
/* 										<label for="RememberMe">Remember Me</label>*/
/* 									</div>*/
/* 								</div>*/
/* 								<div class="col-sm-4 text-right">*/
/* 									<button type="submit" class="btn btn-primary hidden-xs">Sign In</button>*/
/* 									<button type="submit" class="btn btn-primary btn-block btn-lg visible-xs mt-lg">Sign In</button>*/
/* 								</div>*/
/* 							</div>*/
/* 						*/
/* 							<span class="mt-lg mb-lg line-thru text-center text-uppercase">*/
/* 								<span>or</span>*/
/* 							</span>*/
/* */
/* 							<div class="mb-xs text-center">*/
/* 					*/
/* 							<p class="text-center">Don't have an account yet? <a href="http://192.168.33.99/da/signup">Sign Up!</a>*/
/* 							</div>*/
/* */
/* 						</form>*/
/* 					</div>*/
/* 				</div>*/
/* */
/* 				<p class="text-center text-muted mt-md mb-md">&copy; Copyright 2018. All rights reserved. Template by <a href="https://colorlib.com">Colorlib</a>.</p>*/
/* 			</div>*/
/* 		</section>*/
/* 		<!-- end: page -->*/
/* */
/* 		<!-- Vendor -->*/
/* 		<script src="../assets/vendor/jquery/jquery.js"></script>*/
/* 		<script src="../assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>*/
/* 		<script src="../assets/vendor/bootstrap/js/bootstrap.js"></script>*/
/* 		<script src="../assets/vendor/nanoscroller/nanoscroller.js"></script>*/
/* 		<script src="../assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>*/
/* 		<script src="../assets/vendor/magnific-popup/magnific-popup.js"></script>*/
/* 		<script src="../assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>*/
/* 		*/
/* 		<!-- Theme Base, Components and Settings -->*/
/* 		<script src="../assets/javascripts/theme.js"></script>*/
/* 		*/
/* 		<!-- Theme Custom -->*/
/* 		<script src="../assets/javascripts/theme.custom.js"></script>*/
/* 		*/
/* 		<!-- Theme Initialization Files -->*/
/* 		<script src="../assets/javascripts/theme.init.js"></script>*/
/* </html>*/
