<?php

/* index.phtml */
class __TwigTemplate_1bcdeedb4bc35f6530c9842a78c2c5c4de913dce950bd13732fd7a7449ef89ba extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!doctype html>
<html class=\"fixed\">
\t<head>

\t\t<!-- Basic -->
\t\t<meta charset=\"UTF-8\">

\t\t<title>Daily Assi.</title>
\t\t<meta name=\"keywords\" content=\"HTML5 Admin Template\" />
\t\t<meta name=\"description\" content=\"JSOFT Admin - Responsive HTML5 Template\">
\t\t<meta name=\"author\" content=\"JSOFT.net\">

\t\t<!-- Mobile Metas -->
\t\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no\" />

\t\t<!-- Web Fonts  -->
\t\t<link href=\"http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light\" rel=\"stylesheet\" type=\"text/css\">

\t\t<!-- Vendor CSS -->
\t\t<link rel=\"stylesheet\" href=\"../assets/vendor/bootstrap/css/bootstrap.css\" />
\t\t<link rel=\"stylesheet\" href=\"../assets/vendor/font-awesome/css/font-awesome.css\" />
\t\t<link rel=\"stylesheet\" href=\"../assets/vendor/magnific-popup/magnific-popup.css\" />
\t\t<link rel=\"stylesheet\" href=\"../assets/vendor/bootstrap-datepicker/css/datepicker3.css\" />

\t\t<!-- Specific Page Vendor CSS -->
\t\t<link rel=\"stylesheet\" href=\"../assets/vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css\" />
\t\t<link rel=\"stylesheet\" href=\"../assets/vendor/bootstrap-multiselect/bootstrap-multiselect.css\" />
\t\t<link rel=\"stylesheet\" href=\"../assets/vendor/morris/morris.css\" />

\t\t<!-- Theme CSS -->
\t\t<link rel=\"stylesheet\" href=\"../assets/stylesheets/theme.css\" />

\t\t<!-- Skin CSS -->
\t\t<link rel=\"stylesheet\" href=\"../assets/stylesheets/skins/default.css\" />

\t\t<!-- Theme Custom CSS -->
\t\t<link rel=\"stylesheet\" href=\"../assets/stylesheets/theme-custom.css\">

\t\t<!-- Head Libs -->
\t\t<script src=\"../assets/vendor/modernizr/modernizr.js\"></script>
\t\t

\t</head>
\t<body>
\t\t<section class=\"body\">

\t\t\t<!-- start: header -->
\t\t\t<header class=\"header\">
\t\t\t\t<div class=\"logo-container\">
\t\t\t\t\t<form action =\"../da\" method = \"post\" name = \"j\">
\t\t\t\t\t<div onclick =\"document.forms['j'].submit();\" style =\"cursor : pointer;\">
\t\t\t\t\t<a class=\"logo\">
\t\t\t\t\t\t<img src=\"../assets/images/longlogo.png\" height=\"70\" alt=\"JSOFT Admin\" />
\t\t\t\t\t</a>
\t\t\t\t\t</div>
\t\t\t\t\t</form>
\t\t\t\t\t<div class=\"visible-xs toggle-sidebar-left\" data-toggle-class=\"sidebar-left-opened\" data-target=\"html\" data-fire-event=\"sidebar-left-opened\">
\t\t\t\t\t\t<i class=\"fa fa-bars\" aria-label=\"Toggle sidebar\"></i>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t
\t\t\t\t<!-- start: search & user box -->
\t\t\t\t<div class=\"header-right\">
\t\t\t
\t\t\t\t\t<form action=\"pages-search-results.html\" class=\"search nav-form\">
\t\t\t\t\t\t<div class=\"input-group input-search\">
\t\t\t\t\t\t\t<input type=\"text\" class=\"form-control\" name=\"q\" id=\"q\" placeholder=\"Search...\">
\t\t\t\t\t\t\t<span class=\"input-group-btn\">
\t\t\t\t\t\t\t\t<button class=\"btn btn-default\" type=\"submit\"><i class=\"fa fa-search\"></i></button>
\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t</div>
\t\t\t\t\t</form>
\t\t\t
\t\t\t\t\t<span class=\"separator\"></span>
\t\t\t
\t\t\t\t\t<div id=\"userbox\" class=\"userbox\">
\t\t\t\t\t\t<a href=\"#\" data-toggle=\"dropdown\">
\t\t\t\t\t\t\t<figure class=\"profile-picture\">
\t\t\t\t\t\t\t\t<img src=\"../assets/images/!logged-user.jpg\" alt=\"Joey\" class=\"img-circle\" data-lock-picture=\"../assets/images/!logged-user.jpg\" />
\t\t\t\t\t\t\t</figure>
\t\t\t\t\t\t\t<div class=\"profile-info\" data-lock-name=\"John Doe\" data-lock-email=\"johndoe@JSOFT.com\">
\t\t\t\t\t\t\t\t<span class=\"name\">Joey</span>
\t\t\t\t\t\t\t\t<span class=\"role\">administrator</span>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</a>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<!-- end: search & user box -->
\t\t\t</header>
\t\t\t<!-- end: header -->

\t\t\t<div class=\"inner-wrapper\">
\t\t\t\t<!-- start: sidebar -->
\t\t\t\t<aside id=\"sidebar-left\" class=\"sidebar-left\">
\t\t\t\t
\t\t\t\t\t<div class=\"sidebar-header\">
\t\t\t\t\t\t<div class=\"sidebar-title\">
\t\t\t\t\t\tMENU
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"sidebar-toggle hidden-xs\" data-toggle-class=\"sidebar-left-collapsed\" data-target=\"html\" data-fire-event=\"sidebar-left-toggle\">
\t\t\t\t\t\t\t<i class=\"fa fa-bars\" aria-label=\"Toggle sidebar\"></i>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t
\t\t\t\t\t<div class=\"nano\">
\t\t\t\t\t\t<div class=\"nano-content\">
\t\t\t\t\t\t\t<nav id=\"menu\" class=\"nav-main\" role=\"navigation\">
\t\t\t\t\t\t\t\t<ul class=\"nav nav-main\">
\t\t\t\t\t\t\t\t\t<li class=\"nav-active\">
\t\t\t\t\t\t\t\t\t<form action =\"../da\" method = \"post\" name = \"r\">
\t\t\t\t\t\t\t\t\t<div onclick =\"document.forms['r'].submit();\" style =\"cursor : pointer;\">
\t\t\t\t\t\t\t\t\t\t\t<Br>&nbsp;&nbsp;&nbsp;<i class=\"fa fa-home\" aria-hidden=\"true\"></i>
\t\t\t\t\t\t\t\t\t\t\t<span>Home</span>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</form>\t
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t<li class=\"nav-active\">
\t\t\t\t\t\t\t\t\t\t<a href=\"../da/temp\">
\t\t\t\t\t\t\t\t\t\t\t<span>Temperature</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t<li class=\"nav-active\">
\t\t\t\t\t\t\t\t\t\t<a href=\"../da/hr\">
\t\t\t\t\t\t\t\t\t\t\t<span>Heart Rate</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t<li class=\"nav-active\">
\t\t\t\t\t\t\t\t\t\t<a href=\"../da/air\">
\t\t\t\t\t\t\t\t\t\t\t<span>Air Quality</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t\t\t<li class=\"nav-active\">
\t\t\t\t\t\t\t\t\t\t<a href=\"../da/profile\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"pull-right label label-primary\"></span>
\t\t\t\t\t\t\t\t\t\t\t<span>User Profile</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t<li class=\"nav-active\">
\t\t\t\t\t\t\t\t\t<form action =\"../da/signin\" method = \"post\" name = \"o\">
\t\t\t\t\t\t\t\t\t<div onclick =\"document.forms['o'].submit();\" style =\"cursor : pointer;\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"pull-right label label-primary\"></span>
\t\t\t\t\t\t\t\t\t\t\t<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sign Out</span>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</form>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t</ul>\t
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</aside>
\t\t\t
\t\t\t\t<!-- end: sidebar -->

\t\t\t\t<section role=\"main\" class=\"content-body\">
\t\t\t\t\t<header class=\"page-header\">
\t\t\t\t\t\t<h2>Home</h2>
\t\t\t\t\t
\t\t\t\t\t\t<div class=\"right-wrapper pull-right\">
\t\t\t\t\t\t\t<ol class=\"breadcrumbs\">
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"index.html\">
\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-home\"></i>
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li><span>Home</span></li>
\t\t\t\t\t\t\t</ol>
\t\t\t\t\t
\t\t\t\t\t\t\t<a class=\"sidebar-right-toggle\" data-open=\"sidebar-right\"><i class=\"fa fa-chevron-left\"></i></a>
\t\t\t\t\t\t</div>
\t\t\t\t\t</header>
\t\t\t\t\t\t
\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t<section class=\"panel\">
\t\t\t\t\t\t\t\t<header class=\"panel-heading\">
\t\t\t\t\t\t\t\t\t<div class=\"panel-actions\">
\t\t\t\t\t\t\t\t\t\t<a href=\"#\" class=\"fa fa-caret-down\"></a>
\t\t\t\t\t\t\t\t\t\t<a href=\"#\" class=\"fa fa-times\"></a>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<h2 class=\"panel-title\">Today's cloth</h2>
\t\t\t\t\t\t\t\t\t<p class=\"panel-subtitle\">Recommend appropriate clothes, based on real-time temperatures! </p>
\t\t\t\t\t\t\t\t</header>
\t\t\t\t\t\t\t\t<div class=\"panel-body\">
\t\t\t\t\t\t\t\t<p style=\"text-align: center;\">
\t\t\t\t\t\t\t\t<a href = \"../da/temp\"> <img src = \"../assets/images/sun.png\"> 
\t\t\t\t\t\t\t\t<img src = \"../assets/images/clothing.png\"></a><BR> 
\t\t\t\t\t\t\t\t<h1 align = center> 59°F &nbsp; &nbsp; &nbsp; Thin Cloth </h1>
\t\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</section>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t
\t\t\t\t\t\t
\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t<section class=\"panel\">
\t\t\t\t\t\t\t\t<header class=\"panel-heading\">
\t\t\t\t\t\t\t\t\t<div class=\"panel-actions\">
\t\t\t\t\t\t\t\t\t\t<a href=\"#\" class=\"fa fa-caret-down\"></a>
\t\t\t\t\t\t\t\t\t\t<a href=\"#\" class=\"fa fa-times\"></a>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<h2 class=\"panel-title\">Heart Rate</h2>
\t\t\t\t\t\t\t\t\t<p class=\"panel-subtitle\">Check your Heart Rate and Respiratory Rate</p>
\t\t\t\t\t\t\t\t</header>
\t\t\t\t\t\t\t
\t\t\t\t\t\t\t<div class=\"panel-body\">
\t\t\t\t\t\t\t<BR> <BR>
\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t   <section class=\"panel panel-featured-left panel-featured-secondary\">
\t\t\t\t\t\t\t\t\t  <div class=\"panel-body\">
\t\t\t\t\t\t\t\t\t\t <div class=\"widget-summary\">
\t\t\t\t\t\t\t\t\t\t\t<p style=\"text-align: center;\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"widget-summary-col\">
\t\t\t\t\t\t\t\t\t\t\t   <div class=\"summary\">
\t\t\t\t\t\t\t\t\t\t\t   <div  style = \" float : left\">
\t\t\t\t\t\t\t\t\t\t\t\t<img src = \"../assets/images/hr.png\" width = \"100\" > 
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t  <div class=\"info\" style =\" float : left\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<h4 class=\"title\">HR</h4><strong class=\"amount\">109</strong>
\t\t\t\t\t\t\t\t\t\t\t\t  </div>
\t\t\t\t\t\t\t\t\t\t\t   </div>
\t\t\t\t\t\t\t\t\t\t\t   <div class=\"summary-footer\">
\t\t\t\t\t\t\t\t\t\t\t\t  <a class=\"text-muted text-uppercase\" href = \"http://192.168.33.99/da/hr\">(withdraw)</a>
\t\t\t\t\t\t\t\t\t\t\t   </div>
\t\t\t\t\t\t\t\t\t\t\t </P>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t </div>
\t\t\t\t\t\t\t\t   </div>
\t\t\t\t\t\t\t\t   </section>
\t\t\t\t\t\t\t   </div>

\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t   <section class=\"panel panel-featured-left panel-featured-quartenary\">
\t\t\t\t\t\t\t\t\t  <div class=\"panel-body\">
\t\t\t\t\t\t\t\t\t\t <div class=\"widget-summary\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"widget-summary-col\">
\t\t\t\t\t\t\t\t\t\t\t   <div class=\"summary\">
\t\t\t\t\t\t\t\t\t\t\t   <div  style = \" float : left\">
\t\t\t\t\t\t\t\t\t\t\t   <img src = \"../assets/images/rr.png\" width = \"100\"> 
\t\t\t\t\t\t\t\t\t\t\t   </div>
\t\t\t\t\t\t\t\t\t\t\t\t  <div class=\"info\" style =\" float : left\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<h4 class=\"title\">RR</h4><strong class=\"amount\">88.11</strong>
\t\t\t\t\t\t\t\t\t\t\t\t  </div>
\t\t\t\t\t\t\t\t\t\t\t   </div>
\t\t\t\t\t\t\t\t\t\t\t   <div class=\"summary-footer\">
\t\t\t\t\t\t\t\t\t\t\t\t  <a class=\"text-muted text-uppercase\" href = \"http://192.168.33.99/da/hr\">(report)</a>
\t\t\t\t\t\t\t\t\t\t\t   </div>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t </div>
\t\t\t\t\t\t\t\t\t  </div>
\t\t\t\t\t\t\t\t   </section>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<BR> <BR>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t
\t\t\t\t\t\t
\t\t\t\t\t</div>
\t\t\t\t\t\t
\t\t\t\t\t\t
\t\t\t\t\t\t<!--공기쓰-->
\t\t\t\t\t\t<div class=\"column\">
\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t<section class=\"panel panel-transparent\">
\t\t\t\t\t\t\t\t<header class=\"panel-heading\">
\t\t\t\t\t\t\t\t\t<div class=\"panel-actions\">
\t\t\t\t\t\t\t\t\t\t<a href=\"#\" class=\"fa fa-caret-down\"></a>
\t\t\t\t\t\t\t\t\t\t<a href=\"#\" class=\"fa fa-times\"></a>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<h2 class=\"panel-title\">Air Stats</h2>
\t\t\t\t\t\t\t\t</header>
\t\t\t\t\t\t\t\t<section class=\"panel panel-featured-left panel-featured-quartenary\">
\t\t\t\t\t\t\t\t\t\t <div class=\"panel-body\">
\t\t\t\t\t\t\t\t\t\t\t <div class=\"widget-summary\">
\t\t\t\t\t\t\t\t\t\t\t\t<p style=\"text-align: center;\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"widget-summary-col\">
\t\t\t\t\t\t\t\t\t\t\t\t   <div class=\"summary\">
\t\t\t\t\t\t\t\t\t\t\t\t   <div  style = \" float : left\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<img src = \"../assets/images/PM.png\" width = \"100\" > 
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t  <div class=\"info\" style =\" float : left\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<h4 class=\"title\"></h4><strong class=\"amount\">33</strong>

\t\t\t\t\t\t\t\t\t\t\t\t\t  </div>
\t\t\t\t\t\t\t\t\t\t\t\t   </div>
\t\t\t\t\t\t\t\t\t\t\t\t   <div class=\"summary-footer\">
\t\t\t\t\t\t\t\t\t\t\t\t   </div>
\t\t\t\t\t\t\t\t\t\t\t\t </P>
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t </div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</section>
\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t<section class=\"panel panel-featured-left panel-featured-quartenary\">
\t\t\t\t\t\t\t\t\t\t  <div class=\"panel-body\">
\t\t\t\t\t\t\t\t\t\t\t <div class=\"widget-summary\">
\t\t\t\t\t\t\t\t\t\t\t\t<p style=\"text-align: center;\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"widget-summary-col\">
\t\t\t\t\t\t\t\t\t\t\t\t   <div class=\"summary\">
\t\t\t\t\t\t\t\t\t\t\t\t   <div  style = \" float : left\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<img src = \"../assets/images/CO.png\" width = \"100\" > 
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t  <div class=\"info\" style =\" float : left\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<h4 class=\"title\"></h4><strong class=\"amount\">77</strong>

\t\t\t\t\t\t\t\t\t\t\t\t\t  </div>
\t\t\t\t\t\t\t\t\t\t\t\t   </div>
\t\t\t\t\t\t\t\t\t\t\t\t   <div class=\"summary-footer\">
\t\t\t\t\t\t\t\t\t\t\t\t   </div>
\t\t\t\t\t\t\t\t\t\t\t\t </P>
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t </div>
\t\t\t\t\t\t\t\t\t   </div>
\t\t\t\t\t\t\t\t</section>
\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t<section class=\"panel panel-featured-left panel-featured-quartenary\">
\t\t\t\t\t\t\t\t\t\t  <div class=\"panel-body\">
\t\t\t\t\t\t\t\t\t\t\t <div class=\"widget-summary\">
\t\t\t\t\t\t\t\t\t\t\t\t<p style=\"text-align: center;\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"widget-summary-col\">
\t\t\t\t\t\t\t\t\t\t\t\t   <div class=\"summary\">
\t\t\t\t\t\t\t\t\t\t\t\t   <div  style = \" float : left\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<img src = \"../assets/images/SO2.png\" width = \"100\" > 
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t  <div class=\"info\" style =\" float : left\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<h4 class=\"title\"></h4><strong class=\"amount\">177</strong>

\t\t\t\t\t\t\t\t\t\t\t\t\t  </div>
\t\t\t\t\t\t\t\t\t\t\t\t   </div>
\t\t\t\t\t\t\t\t\t\t\t\t   <div class=\"summary-footer\">
\t\t\t\t\t\t\t\t\t\t\t\t   </div>
\t\t\t\t\t\t\t\t\t\t\t\t </P>
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t </div>
\t\t\t\t\t\t\t\t\t   </div>
\t\t\t\t\t\t\t\t</section>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t

\t\t\t\t\t\t<br> <br> <br>
\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t
\t\t\t\t\t\t\t<section class=\"panel panel-featured-left panel-featured-quartenary\">
\t\t\t\t\t\t\t\t\t  <div class=\"panel-body\">
\t\t\t\t\t\t\t\t\t\t <div class=\"widget-summary\">
\t\t\t\t\t\t\t\t\t\t\t<p style=\"text-align: center;\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"widget-summary-col\">
\t\t\t\t\t\t\t\t\t\t\t   <div class=\"summary\">
\t\t\t\t\t\t\t\t\t\t\t   <div  style = \" float : left\">
\t\t\t\t\t\t\t\t\t\t\t\t<img src = \"../assets/images/NO2.png\" width = \"100\" > 
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t  <div class=\"info\" style =\" float : left\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<h4 class=\"title\"></h4><strong class=\"amount\">256</strong>
\t\t\t\t\t\t\t\t\t\t\t\t  </div>
\t\t\t\t\t\t\t\t\t\t\t   </div>
\t\t\t\t\t\t\t\t\t\t\t   <div class=\"summary-footer\">
\t\t\t\t\t\t\t\t\t\t\t   </div>
\t\t\t\t\t\t\t\t\t\t\t </P>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t </div>
\t\t\t\t\t\t\t\t   </div>
\t\t\t\t\t\t\t</section>
\t\t\t\t\t\t\t
\t\t\t\t\t\t\t<section class=\"panel panel-featured-left panel-featured-quartenary\">
\t\t\t\t\t\t\t\t\t  <div class=\"panel-body\">
\t\t\t\t\t\t\t\t\t\t <div class=\"widget-summary\">
\t\t\t\t\t\t\t\t\t\t\t<p style=\"text-align: center;\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"widget-summary-col\">
\t\t\t\t\t\t\t\t\t\t\t   <div class=\"summary\">
\t\t\t\t\t\t\t\t\t\t\t   <div  style = \" float : left\">
\t\t\t\t\t\t\t\t\t\t\t\t<img src = \"../assets/images/O3.png\" width = \"100\" > 
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t  <div class=\"info\" style =\" float : left\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<h4 class=\"title\"></h4><strong class=\"amount\">399</strong>
\t\t\t\t\t\t\t\t\t\t\t\t  </div>
\t\t\t\t\t\t\t\t\t\t\t   </div>
\t\t\t\t\t\t\t\t\t\t\t   <div class=\"summary-footer\">
\t\t\t\t\t\t\t\t\t\t\t   </div>
\t\t\t\t\t\t\t\t\t\t\t </P>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t </div>
\t\t\t\t\t\t\t\t   </div>
\t\t\t\t\t\t\t</section>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t</section>

\t\t<!-- Vendor -->
\t\t<script src=\"../assets/vendor/jquery/jquery.js\"></script>
\t\t<script src=\"../assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js\"></script>
\t\t<script src=\"../assets/vendor/bootstrap/js/bootstrap.js\"></script>
\t\t<script src=\"../assets/vendor/nanoscroller/nanoscroller.js\"></script>
\t\t<script src=\"../assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js\"></script>
\t\t<script src=\"../assets/vendor/magnific-popup/magnific-popup.js\"></script>
\t\t<script src=\"../assets/vendor/jquery-placeholder/jquery.placeholder.js\"></script>
\t\t
\t\t<!-- Specific Page Vendor -->
\t\t<script src=\"../assets/vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js\"></script>
\t\t<script src=\"../assets/vendor/jquery-ui-touch-punch/jquery.ui.touch-punch.js\"></script>
\t\t<script src=\"../assets/vendor/jquery-appear/jquery.appear.js\"></script>
\t\t<script src=\"../assets/vendor/bootstrap-multiselect/bootstrap-multiselect.js\"></script>
\t\t<script src=\"../assets/vendor/jquery-easypiechart/jquery.easypiechart.js\"></script>
\t\t<script src=\"../assets/vendor/flot/jquery.flot.js\"></script>
\t\t<script src=\"../assets/vendor/flot-tooltip/jquery.flot.tooltip.js\"></script>
\t\t<script src=\"../assets/vendor/flot/jquery.flot.pie.js\"></script>
\t\t<script src=\"../assets/vendor/flot/jquery.flot.categories.js\"></script>
\t\t<script src=\"../assets/vendor/flot/jquery.flot.resize.js\"></script>
\t\t<script src=\"../assets/vendor/jquery-sparkline/jquery.sparkline.js\"></script>
\t\t<script src=\"../assets/vendor/raphael/raphael.js\"></script>
\t\t<script src=\"../assets/vendor/morris/morris.js\"></script>
\t\t<script src=\"../assets/vendor/gauge/gauge.js\"></script>
\t\t<script src=\"../assets/vendor/snap-svg/snap.svg.js\"></script>
\t\t<script src=\"../assets/vendor/liquid-meter/liquid.meter.js\"></script>
\t\t<script src=\"../assets/vendor/jqvmap/jquery.vmap.js\"></script>
\t\t<script src=\"../assets/vendor/jqvmap/data/jquery.vmap.sampledata.js\"></script>
\t\t<script src=\"../assets/vendor/jqvmap/maps/jquery.vmap.world.js\"></script>
\t\t<script src=\"../assets/vendor/jqvmap/maps/continents/jquery.vmap.africa.js\"></script>
\t\t<script src=\"../assets/vendor/jqvmap/maps/continents/jquery.vmap.asia.js\"></script>
\t\t<script src=\"../assets/vendor/jqvmap/maps/continents/jquery.vmap.australia.js\"></script>
\t\t<script src=\"../assets/vendor/jqvmap/maps/continents/jquery.vmap.europe.js\"></script>
\t\t<script src=\"../assets/vendor/jqvmap/maps/continents/jquery.vmap.north-america.js\"></script>
\t\t<script src=\"../assets/vendor/jqvmap/maps/continents/jquery.vmap.south-america.js\"></script>
\t\t
\t\t<!-- Theme Base, Components and Settings -->
\t\t<script src=\"../assets/javascripts/theme.js\"></script>
\t\t
\t\t<!-- Theme Custom -->
\t\t<script src=\"../assets/javascripts/theme.custom.js\"></script>
\t\t
\t\t<!-- Theme Initialization Files -->
\t\t<script src=\"../assets/javascripts/theme.init.js\"></script>


\t\t<!-- Examples -->
\t\t<script src=\"../assets/javascripts/dashboard/examples.dashboard.js\"></script>
\t</body>
</html>";
    }

    public function getTemplateName()
    {
        return "index.phtml";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
/* <!doctype html>*/
/* <html class="fixed">*/
/* 	<head>*/
/* */
/* 		<!-- Basic -->*/
/* 		<meta charset="UTF-8">*/
/* */
/* 		<title>Daily Assi.</title>*/
/* 		<meta name="keywords" content="HTML5 Admin Template" />*/
/* 		<meta name="description" content="JSOFT Admin - Responsive HTML5 Template">*/
/* 		<meta name="author" content="JSOFT.net">*/
/* */
/* 		<!-- Mobile Metas -->*/
/* 		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />*/
/* */
/* 		<!-- Web Fonts  -->*/
/* 		<link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">*/
/* */
/* 		<!-- Vendor CSS -->*/
/* 		<link rel="stylesheet" href="../assets/vendor/bootstrap/css/bootstrap.css" />*/
/* 		<link rel="stylesheet" href="../assets/vendor/font-awesome/css/font-awesome.css" />*/
/* 		<link rel="stylesheet" href="../assets/vendor/magnific-popup/magnific-popup.css" />*/
/* 		<link rel="stylesheet" href="../assets/vendor/bootstrap-datepicker/css/datepicker3.css" />*/
/* */
/* 		<!-- Specific Page Vendor CSS -->*/
/* 		<link rel="stylesheet" href="../assets/vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />*/
/* 		<link rel="stylesheet" href="../assets/vendor/bootstrap-multiselect/bootstrap-multiselect.css" />*/
/* 		<link rel="stylesheet" href="../assets/vendor/morris/morris.css" />*/
/* */
/* 		<!-- Theme CSS -->*/
/* 		<link rel="stylesheet" href="../assets/stylesheets/theme.css" />*/
/* */
/* 		<!-- Skin CSS -->*/
/* 		<link rel="stylesheet" href="../assets/stylesheets/skins/default.css" />*/
/* */
/* 		<!-- Theme Custom CSS -->*/
/* 		<link rel="stylesheet" href="../assets/stylesheets/theme-custom.css">*/
/* */
/* 		<!-- Head Libs -->*/
/* 		<script src="../assets/vendor/modernizr/modernizr.js"></script>*/
/* 		*/
/* */
/* 	</head>*/
/* 	<body>*/
/* 		<section class="body">*/
/* */
/* 			<!-- start: header -->*/
/* 			<header class="header">*/
/* 				<div class="logo-container">*/
/* 					<form action ="../da" method = "post" name = "j">*/
/* 					<div onclick ="document.forms['j'].submit();" style ="cursor : pointer;">*/
/* 					<a class="logo">*/
/* 						<img src="../assets/images/longlogo.png" height="70" alt="JSOFT Admin" />*/
/* 					</a>*/
/* 					</div>*/
/* 					</form>*/
/* 					<div class="visible-xs toggle-sidebar-left" data-toggle-class="sidebar-left-opened" data-target="html" data-fire-event="sidebar-left-opened">*/
/* 						<i class="fa fa-bars" aria-label="Toggle sidebar"></i>*/
/* 					</div>*/
/* 				</div>*/
/* 			*/
/* 				<!-- start: search & user box -->*/
/* 				<div class="header-right">*/
/* 			*/
/* 					<form action="pages-search-results.html" class="search nav-form">*/
/* 						<div class="input-group input-search">*/
/* 							<input type="text" class="form-control" name="q" id="q" placeholder="Search...">*/
/* 							<span class="input-group-btn">*/
/* 								<button class="btn btn-default" type="submit"><i class="fa fa-search"></i></button>*/
/* 							</span>*/
/* 						</div>*/
/* 					</form>*/
/* 			*/
/* 					<span class="separator"></span>*/
/* 			*/
/* 					<div id="userbox" class="userbox">*/
/* 						<a href="#" data-toggle="dropdown">*/
/* 							<figure class="profile-picture">*/
/* 								<img src="../assets/images/!logged-user.jpg" alt="Joey" class="img-circle" data-lock-picture="../assets/images/!logged-user.jpg" />*/
/* 							</figure>*/
/* 							<div class="profile-info" data-lock-name="John Doe" data-lock-email="johndoe@JSOFT.com">*/
/* 								<span class="name">Joey</span>*/
/* 								<span class="role">administrator</span>*/
/* 							</div>*/
/* 						</a>*/
/* 					</div>*/
/* 				</div>*/
/* 				<!-- end: search & user box -->*/
/* 			</header>*/
/* 			<!-- end: header -->*/
/* */
/* 			<div class="inner-wrapper">*/
/* 				<!-- start: sidebar -->*/
/* 				<aside id="sidebar-left" class="sidebar-left">*/
/* 				*/
/* 					<div class="sidebar-header">*/
/* 						<div class="sidebar-title">*/
/* 						MENU*/
/* 						</div>*/
/* 						<div class="sidebar-toggle hidden-xs" data-toggle-class="sidebar-left-collapsed" data-target="html" data-fire-event="sidebar-left-toggle">*/
/* 							<i class="fa fa-bars" aria-label="Toggle sidebar"></i>*/
/* 						</div>*/
/* 					</div>*/
/* 				*/
/* 					<div class="nano">*/
/* 						<div class="nano-content">*/
/* 							<nav id="menu" class="nav-main" role="navigation">*/
/* 								<ul class="nav nav-main">*/
/* 									<li class="nav-active">*/
/* 									<form action ="../da" method = "post" name = "r">*/
/* 									<div onclick ="document.forms['r'].submit();" style ="cursor : pointer;">*/
/* 											<Br>&nbsp;&nbsp;&nbsp;<i class="fa fa-home" aria-hidden="true"></i>*/
/* 											<span>Home</span>*/
/* 									</div>*/
/* 									</form>	*/
/* 									</li>*/
/* 									*/
/* 									<li class="nav-active">*/
/* 										<a href="../da/temp">*/
/* 											<span>Temperature</span>*/
/* 										</a>*/
/* 									</li>*/
/* 									*/
/* 									<li class="nav-active">*/
/* 										<a href="../da/hr">*/
/* 											<span>Heart Rate</span>*/
/* 										</a>*/
/* 									</li>*/
/* 									*/
/* 									<li class="nav-active">*/
/* 										<a href="../da/air">*/
/* 											<span>Air Quality</span>*/
/* 										</a>*/
/* 									</li>*/
/* */
/* 									<li class="nav-active">*/
/* 										<a href="../da/profile">*/
/* 											<span class="pull-right label label-primary"></span>*/
/* 											<span>User Profile</span>*/
/* 										</a>*/
/* 									</li>*/
/* 									*/
/* 									<li class="nav-active">*/
/* 									<form action ="../da/signin" method = "post" name = "o">*/
/* 									<div onclick ="document.forms['o'].submit();" style ="cursor : pointer;">*/
/* 											<span class="pull-right label label-primary"></span>*/
/* 											<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sign Out</span>*/
/* 									</div>*/
/* 									</form>*/
/* 									</li>*/
/* 								*/
/* 								</ul>	*/
/* 						</div>*/
/* 					</div>*/
/* 				</aside>*/
/* 			*/
/* 				<!-- end: sidebar -->*/
/* */
/* 				<section role="main" class="content-body">*/
/* 					<header class="page-header">*/
/* 						<h2>Home</h2>*/
/* 					*/
/* 						<div class="right-wrapper pull-right">*/
/* 							<ol class="breadcrumbs">*/
/* 								<li>*/
/* 									<a href="index.html">*/
/* 										<i class="fa fa-home"></i>*/
/* 									</a>*/
/* 								</li>*/
/* 								<li><span>Home</span></li>*/
/* 							</ol>*/
/* 					*/
/* 							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>*/
/* 						</div>*/
/* 					</header>*/
/* 						*/
/* 						<div class="row">*/
/* 						<div class="col-md-6">*/
/* 							<section class="panel">*/
/* 								<header class="panel-heading">*/
/* 									<div class="panel-actions">*/
/* 										<a href="#" class="fa fa-caret-down"></a>*/
/* 										<a href="#" class="fa fa-times"></a>*/
/* 									</div>*/
/* 									<h2 class="panel-title">Today's cloth</h2>*/
/* 									<p class="panel-subtitle">Recommend appropriate clothes, based on real-time temperatures! </p>*/
/* 								</header>*/
/* 								<div class="panel-body">*/
/* 								<p style="text-align: center;">*/
/* 								<a href = "../da/temp"> <img src = "../assets/images/sun.png"> */
/* 								<img src = "../assets/images/clothing.png"></a><BR> */
/* 								<h1 align = center> 59°F &nbsp; &nbsp; &nbsp; Thin Cloth </h1>*/
/* 								</p>*/
/* 								</div>*/
/* 							</section>*/
/* 						</div>*/
/* 						*/
/* 						*/
/* 						<div class="row">*/
/* 						<div class="col-md-6">*/
/* 							<section class="panel">*/
/* 								<header class="panel-heading">*/
/* 									<div class="panel-actions">*/
/* 										<a href="#" class="fa fa-caret-down"></a>*/
/* 										<a href="#" class="fa fa-times"></a>*/
/* 									</div>*/
/* 									<h2 class="panel-title">Heart Rate</h2>*/
/* 									<p class="panel-subtitle">Check your Heart Rate and Respiratory Rate</p>*/
/* 								</header>*/
/* 							*/
/* 							<div class="panel-body">*/
/* 							<BR> <BR>*/
/* 							*/
/* 								<div class="col-md-6">*/
/* 								   <section class="panel panel-featured-left panel-featured-secondary">*/
/* 									  <div class="panel-body">*/
/* 										 <div class="widget-summary">*/
/* 											<p style="text-align: center;">*/
/* 											<div class="widget-summary-col">*/
/* 											   <div class="summary">*/
/* 											   <div  style = " float : left">*/
/* 												<img src = "../assets/images/hr.png" width = "100" > */
/* 												</div>*/
/* 												  <div class="info" style =" float : left">*/
/* 													<h4 class="title">HR</h4><strong class="amount">109</strong>*/
/* 												  </div>*/
/* 											   </div>*/
/* 											   <div class="summary-footer">*/
/* 												  <a class="text-muted text-uppercase" href = "http://192.168.33.99/da/hr">(withdraw)</a>*/
/* 											   </div>*/
/* 											 </P>*/
/* 											</div>*/
/* 										 </div>*/
/* 								   </div>*/
/* 								   </section>*/
/* 							   </div>*/
/* */
/* 								<div class="col-md-6">*/
/* 								   <section class="panel panel-featured-left panel-featured-quartenary">*/
/* 									  <div class="panel-body">*/
/* 										 <div class="widget-summary">*/
/* 											<div class="widget-summary-col">*/
/* 											   <div class="summary">*/
/* 											   <div  style = " float : left">*/
/* 											   <img src = "../assets/images/rr.png" width = "100"> */
/* 											   </div>*/
/* 												  <div class="info" style =" float : left">*/
/* 													<h4 class="title">RR</h4><strong class="amount">88.11</strong>*/
/* 												  </div>*/
/* 											   </div>*/
/* 											   <div class="summary-footer">*/
/* 												  <a class="text-muted text-uppercase" href = "http://192.168.33.99/da/hr">(report)</a>*/
/* 											   </div>*/
/* 											</div>*/
/* 										 </div>*/
/* 									  </div>*/
/* 								   </section>*/
/* 								</div>*/
/* 							<BR> <BR>*/
/* 							</div>*/
/* 						</div>*/
/* 						</div>*/
/* 						*/
/* 						*/
/* 					</div>*/
/* 						*/
/* 						*/
/* 						<!--공기쓰-->*/
/* 						<div class="column">*/
/* 							<div class="col-md-6">*/
/* 							<section class="panel panel-transparent">*/
/* 								<header class="panel-heading">*/
/* 									<div class="panel-actions">*/
/* 										<a href="#" class="fa fa-caret-down"></a>*/
/* 										<a href="#" class="fa fa-times"></a>*/
/* 									</div>*/
/* 									<h2 class="panel-title">Air Stats</h2>*/
/* 								</header>*/
/* 								<section class="panel panel-featured-left panel-featured-quartenary">*/
/* 										 <div class="panel-body">*/
/* 											 <div class="widget-summary">*/
/* 												<p style="text-align: center;">*/
/* 												<div class="widget-summary-col">*/
/* 												   <div class="summary">*/
/* 												   <div  style = " float : left">*/
/* 													<img src = "../assets/images/PM.png" width = "100" > */
/* 													</div>*/
/* 													  <div class="info" style =" float : left">*/
/* 														<h4 class="title"></h4><strong class="amount">33</strong>*/
/* */
/* 													  </div>*/
/* 												   </div>*/
/* 												   <div class="summary-footer">*/
/* 												   </div>*/
/* 												 </P>*/
/* 												</div>*/
/* 											 </div>*/
/* 										</div>*/
/* 								</section>*/
/* 								*/
/* 								<section class="panel panel-featured-left panel-featured-quartenary">*/
/* 										  <div class="panel-body">*/
/* 											 <div class="widget-summary">*/
/* 												<p style="text-align: center;">*/
/* 												<div class="widget-summary-col">*/
/* 												   <div class="summary">*/
/* 												   <div  style = " float : left">*/
/* 													<img src = "../assets/images/CO.png" width = "100" > */
/* 													</div>*/
/* 													  <div class="info" style =" float : left">*/
/* 														<h4 class="title"></h4><strong class="amount">77</strong>*/
/* */
/* 													  </div>*/
/* 												   </div>*/
/* 												   <div class="summary-footer">*/
/* 												   </div>*/
/* 												 </P>*/
/* 												</div>*/
/* 											 </div>*/
/* 									   </div>*/
/* 								</section>*/
/* 								*/
/* 								<section class="panel panel-featured-left panel-featured-quartenary">*/
/* 										  <div class="panel-body">*/
/* 											 <div class="widget-summary">*/
/* 												<p style="text-align: center;">*/
/* 												<div class="widget-summary-col">*/
/* 												   <div class="summary">*/
/* 												   <div  style = " float : left">*/
/* 													<img src = "../assets/images/SO2.png" width = "100" > */
/* 													</div>*/
/* 													  <div class="info" style =" float : left">*/
/* 														<h4 class="title"></h4><strong class="amount">177</strong>*/
/* */
/* 													  </div>*/
/* 												   </div>*/
/* 												   <div class="summary-footer">*/
/* 												   </div>*/
/* 												 </P>*/
/* 												</div>*/
/* 											 </div>*/
/* 									   </div>*/
/* 								</section>*/
/* 						</div>*/
/* 						</div>*/
/* 						*/
/* */
/* 						<br> <br> <br>*/
/* 						<div class="row">*/
/* 						<div class="col-md-6">*/
/* 						*/
/* 							<section class="panel panel-featured-left panel-featured-quartenary">*/
/* 									  <div class="panel-body">*/
/* 										 <div class="widget-summary">*/
/* 											<p style="text-align: center;">*/
/* 											<div class="widget-summary-col">*/
/* 											   <div class="summary">*/
/* 											   <div  style = " float : left">*/
/* 												<img src = "../assets/images/NO2.png" width = "100" > */
/* 												</div>*/
/* 												  <div class="info" style =" float : left">*/
/* 													<h4 class="title"></h4><strong class="amount">256</strong>*/
/* 												  </div>*/
/* 											   </div>*/
/* 											   <div class="summary-footer">*/
/* 											   </div>*/
/* 											 </P>*/
/* 											</div>*/
/* 										 </div>*/
/* 								   </div>*/
/* 							</section>*/
/* 							*/
/* 							<section class="panel panel-featured-left panel-featured-quartenary">*/
/* 									  <div class="panel-body">*/
/* 										 <div class="widget-summary">*/
/* 											<p style="text-align: center;">*/
/* 											<div class="widget-summary-col">*/
/* 											   <div class="summary">*/
/* 											   <div  style = " float : left">*/
/* 												<img src = "../assets/images/O3.png" width = "100" > */
/* 												</div>*/
/* 												  <div class="info" style =" float : left">*/
/* 													<h4 class="title"></h4><strong class="amount">399</strong>*/
/* 												  </div>*/
/* 											   </div>*/
/* 											   <div class="summary-footer">*/
/* 											   </div>*/
/* 											 </P>*/
/* 											</div>*/
/* 										 </div>*/
/* 								   </div>*/
/* 							</section>*/
/* 						</div>*/
/* 						</div>*/
/* 				</section>*/
/* */
/* 		<!-- Vendor -->*/
/* 		<script src="../assets/vendor/jquery/jquery.js"></script>*/
/* 		<script src="../assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>*/
/* 		<script src="../assets/vendor/bootstrap/js/bootstrap.js"></script>*/
/* 		<script src="../assets/vendor/nanoscroller/nanoscroller.js"></script>*/
/* 		<script src="../assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>*/
/* 		<script src="../assets/vendor/magnific-popup/magnific-popup.js"></script>*/
/* 		<script src="../assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>*/
/* 		*/
/* 		<!-- Specific Page Vendor -->*/
/* 		<script src="../assets/vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js"></script>*/
/* 		<script src="../assets/vendor/jquery-ui-touch-punch/jquery.ui.touch-punch.js"></script>*/
/* 		<script src="../assets/vendor/jquery-appear/jquery.appear.js"></script>*/
/* 		<script src="../assets/vendor/bootstrap-multiselect/bootstrap-multiselect.js"></script>*/
/* 		<script src="../assets/vendor/jquery-easypiechart/jquery.easypiechart.js"></script>*/
/* 		<script src="../assets/vendor/flot/jquery.flot.js"></script>*/
/* 		<script src="../assets/vendor/flot-tooltip/jquery.flot.tooltip.js"></script>*/
/* 		<script src="../assets/vendor/flot/jquery.flot.pie.js"></script>*/
/* 		<script src="../assets/vendor/flot/jquery.flot.categories.js"></script>*/
/* 		<script src="../assets/vendor/flot/jquery.flot.resize.js"></script>*/
/* 		<script src="../assets/vendor/jquery-sparkline/jquery.sparkline.js"></script>*/
/* 		<script src="../assets/vendor/raphael/raphael.js"></script>*/
/* 		<script src="../assets/vendor/morris/morris.js"></script>*/
/* 		<script src="../assets/vendor/gauge/gauge.js"></script>*/
/* 		<script src="../assets/vendor/snap-svg/snap.svg.js"></script>*/
/* 		<script src="../assets/vendor/liquid-meter/liquid.meter.js"></script>*/
/* 		<script src="../assets/vendor/jqvmap/jquery.vmap.js"></script>*/
/* 		<script src="../assets/vendor/jqvmap/data/jquery.vmap.sampledata.js"></script>*/
/* 		<script src="../assets/vendor/jqvmap/maps/jquery.vmap.world.js"></script>*/
/* 		<script src="../assets/vendor/jqvmap/maps/continents/jquery.vmap.africa.js"></script>*/
/* 		<script src="../assets/vendor/jqvmap/maps/continents/jquery.vmap.asia.js"></script>*/
/* 		<script src="../assets/vendor/jqvmap/maps/continents/jquery.vmap.australia.js"></script>*/
/* 		<script src="../assets/vendor/jqvmap/maps/continents/jquery.vmap.europe.js"></script>*/
/* 		<script src="../assets/vendor/jqvmap/maps/continents/jquery.vmap.north-america.js"></script>*/
/* 		<script src="../assets/vendor/jqvmap/maps/continents/jquery.vmap.south-america.js"></script>*/
/* 		*/
/* 		<!-- Theme Base, Components and Settings -->*/
/* 		<script src="../assets/javascripts/theme.js"></script>*/
/* 		*/
/* 		<!-- Theme Custom -->*/
/* 		<script src="../assets/javascripts/theme.custom.js"></script>*/
/* 		*/
/* 		<!-- Theme Initialization Files -->*/
/* 		<script src="../assets/javascripts/theme.init.js"></script>*/
/* */
/* */
/* 		<!-- Examples -->*/
/* 		<script src="../assets/javascripts/dashboard/examples.dashboard.js"></script>*/
/* 	</body>*/
/* </html>*/
