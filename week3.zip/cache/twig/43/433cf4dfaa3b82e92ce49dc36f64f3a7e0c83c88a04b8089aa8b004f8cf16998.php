<?php

/* pages-user-profile.phtml */
class __TwigTemplate_6356eaacf11230730cc9fbe7933482568fdcc3831173c9a3bb8545275937837c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!doctype html>
<html class=\"fixed\">
\t<head>

\t\t<!-- Basic -->
\t\t<meta charset=\"UTF-8\">

\t\t<title>User Profile</title>
\t\t<meta name=\"keywords\" content=\"HTML5 Admin Template\" />
\t\t<meta name=\"description\" content=\"Porto Admin - Responsive HTML5 Template\">
\t\t<meta name=\"author\" content=\"okler.net\">

\t\t<!-- Mobile Metas -->
\t\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no\" />

\t\t<!-- Web Fonts  -->
\t\t<link href=\"http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light\" rel=\"stylesheet\" type=\"text/css\">

\t\t<!-- Vendor CSS -->
\t\t<link rel=\"stylesheet\" href=\"../assets/vendor/bootstrap/css/bootstrap.css\" />
\t\t<link rel=\"stylesheet\" href=\"../assets/vendor/font-awesome/css/font-awesome.css\" />
\t\t<link rel=\"stylesheet\" href=\"../assets/vendor/magnific-popup/magnific-popup.css\" />
\t\t<link rel=\"stylesheet\" href=\"../assets/vendor/bootstrap-datepicker/css/datepicker3.css\" />

\t\t<!-- Theme CSS -->
\t\t<link rel=\"stylesheet\" href=\"../assets/stylesheets/theme.css\" />

\t\t<!-- Skin CSS -->
\t\t<link rel=\"stylesheet\" href=\"../assets/stylesheets/skins/default.css\" />

\t\t<!-- Theme Custom CSS -->
\t\t<link rel=\"stylesheet\" href=\"../assets/stylesheets/theme-custom.css\">

\t\t<!-- Head Libs -->
\t\t<script src=\"../assets/vendor/modernizr/modernizr.js\"></script>

\t</head>
\t<body>
\t\t<section class=\"body\">

\t\t\t<!-- start: header -->
\t\t\t<header class=\"header\">
\t\t\t\t<div class=\"logo-container\">
\t\t\t\t\t<form action =\"../da\" method = \"post\" name = \"j\">
\t\t\t\t\t<div onclick =\"document.forms['j'].submit();\" style =\"cursor : pointer;\">
\t\t\t\t\t<a class=\"logo\">
\t\t\t\t\t\t<img src=\"../assets/images/longlogo.png\" height=\"70\" alt=\"JSOFT Admin\" />
\t\t\t\t\t</a>
\t\t\t\t\t</div>
\t\t\t\t\t</form>
\t\t\t\t\t<div class=\"visible-xs toggle-sidebar-left\" data-toggle-class=\"sidebar-left-opened\" data-target=\"html\" data-fire-event=\"sidebar-left-opened\">
\t\t\t\t\t\t<i class=\"fa fa-bars\" aria-label=\"Toggle sidebar\"></i>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t
\t\t\t\t<!-- start: search & user box -->
\t\t\t\t<div class=\"header-right\">
\t\t\t
\t\t\t\t\t<form action=\"pages-search-results.html\" class=\"search nav-form\">
\t\t\t\t\t\t<div class=\"input-group input-search\">
\t\t\t\t\t\t\t<input type=\"text\" class=\"form-control\" name=\"q\" id=\"q\" placeholder=\"Search...\">
\t\t\t\t\t\t\t<span class=\"input-group-btn\">
\t\t\t\t\t\t\t\t<button class=\"btn btn-default\" type=\"submit\"><i class=\"fa fa-search\"></i></button>
\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t</div>
\t\t\t\t\t</form>
\t\t\t
\t\t\t\t\t<span class=\"separator\"></span>
\t\t\t
\t\t\t\t\t<div id=\"userbox\" class=\"userbox\">
\t\t\t\t\t\t<a href=\"#\" data-toggle=\"dropdown\">
\t\t\t\t\t\t\t<figure class=\"profile-picture\">
\t\t\t\t\t\t\t\t<img src=\"../assets/images/!logged-user.jpg\" alt=\"Joey\" class=\"img-circle\" data-lock-picture=\"../assets/images/!logged-user.jpg\" />
\t\t\t\t\t\t\t</figure>
\t\t\t\t\t\t\t<div class=\"profile-info\" data-lock-name=\"John Doe\" data-lock-email=\"johndoe@JSOFT.com\">
\t\t\t\t\t\t\t\t<span class=\"name\">Joey</span>
\t\t\t\t\t\t\t\t<span class=\"role\">administrator</span>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</a>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<!-- end: search & user box -->
\t\t\t</header>
\t\t\t<!-- end: header -->

\t\t\t<div class=\"inner-wrapper\">
\t\t\t\t<!-- start: sidebar -->
\t\t\t\t<aside id=\"sidebar-left\" class=\"sidebar-left\">
\t\t\t\t
\t\t\t\t\t<div class=\"sidebar-header\">
\t\t\t\t\t\t<div class=\"sidebar-title\">
\t\t\t\t\t\tMENU
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"sidebar-toggle hidden-xs\" data-toggle-class=\"sidebar-left-collapsed\" data-target=\"html\" data-fire-event=\"sidebar-left-toggle\">
\t\t\t\t\t\t\t<i class=\"fa fa-bars\" aria-label=\"Toggle sidebar\"></i>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t
\t\t\t\t\t<div class=\"nano\">
\t\t\t\t\t\t<div class=\"nano-content\">
\t\t\t\t\t\t\t<nav id=\"menu\" class=\"nav-main\" role=\"navigation\">
\t\t\t\t\t\t\t\t<ul class=\"nav nav-main\">
\t\t\t\t\t\t\t\t\t<li class=\"nav-active\">
\t\t\t\t\t\t\t\t\t<form action =\"../da\" method = \"post\" name = \"r\">
\t\t\t\t\t\t\t\t\t<div onclick =\"document.forms['r'].submit();\" style =\"cursor : pointer;\">
\t\t\t\t\t\t\t\t\t\t\t<Br>&nbsp;&nbsp;&nbsp;<i class=\"fa fa-home\" aria-hidden=\"true\"></i>
\t\t\t\t\t\t\t\t\t\t\t<span>Home</span>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</form>\t
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t<li class=\"nav-active\">
\t\t\t\t\t\t\t\t\t\t<a href=\"../da/temp\">
\t\t\t\t\t\t\t\t\t\t\t<span>Temperature</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t<li class=\"nav-active\">
\t\t\t\t\t\t\t\t\t\t<a href=\"../da/hr\">
\t\t\t\t\t\t\t\t\t\t\t<span>Heart Rate</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t<li class=\"nav-active\">
\t\t\t\t\t\t\t\t\t\t<a href=\"../da/air\">
\t\t\t\t\t\t\t\t\t\t\t<span>Air Quality</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"../da/profile\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"pull-right label label-primary\"></span>
\t\t\t\t\t\t\t\t\t\t\t<span>User Profile</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t<li class=\"nav-active\">
\t\t\t\t\t\t\t\t\t<form action =\"../da/signin\" method = \"post\" name = \"r\">
\t\t\t\t\t\t\t\t\t<div onclick =\"document.forms['r'].submit();\" style =\"cursor : pointer;\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"pull-right label label-primary\"></span>
\t\t\t\t\t\t\t\t\t\t\t<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sign Out</span>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</form>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t</ul>\t
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</aside>
\t\t\t
\t\t\t\t<!-- end: sidebar -->

\t\t\t\t<section role=\"main\" class=\"content-body\">
\t\t\t\t\t<header class=\"page-header\">
\t\t\t\t\t\t<h2>User Profile</h2>
\t\t\t\t\t
\t\t\t\t\t\t<div class=\"right-wrapper pull-right\">
\t\t\t\t\t\t\t<ol class=\"breadcrumbs\">
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"index.html\">
\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-home\"></i>
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li><span>Pages</span></li>
\t\t\t\t\t\t\t\t<li><span>User Profile</span></li>
\t\t\t\t\t\t\t</ol>
\t\t\t\t\t
\t\t\t\t\t\t\t<a class=\"sidebar-right-toggle\" data-open=\"sidebar-right\"><i class=\"fa fa-chevron-left\"></i></a>
\t\t\t\t\t\t</div>
\t\t\t\t\t</header>

\t\t\t\t\t<!-- start: page -->

\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t<p style=\"text-align: center;\">
\t\t\t\t\t\t<div class=\"col-md-8 col-lg-6\">
\t\t\t\t\t\t<div style =  margint-left: auto; margin-right: auto;>

\t\t\t\t\t\t\t<div class=\"tabs\">
\t\t\t\t\t\t\t\t<ul class=\"nav nav-tabs tabs-primary\">
\t\t\t\t\t\t\t\t\t<li class=\"active\">
\t\t\t\t\t\t\t\t\t\t<a href=\"#overview\" data-toggle=\"tab\">My profile</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t<div class=\"tab-content\">
\t\t\t\t\t\t\t\t\t<div id=\"overview\" class=\"tab-pane active\">
\t\t\t\t\t\t\t\t\t\t<h4 class=\"mb-md\"></h4>
\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t\t<h5> E-mail </h5>
\t\t\t\t\t\t\t\t\t\t\t<hr color =\"black\">
\t\t\t\t\t\t\t\t\t\t\t<h5> First Name</h5>
\t\t\t\t\t\t\t\t\t\t\t<hr color =\"black\">
\t\t\t\t\t\t\t\t\t\t\t<h5> Last Name</h5>
\t\t\t\t\t\t\t\t\t\t\t<hr color =\"black\">
\t\t\t\t\t\t\t\t\t\t\t<h5> Gender </h5>
\t\t\t\t\t\t\t\t\t\t\t<hr color =\"black\">
\t\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t\t<hr class=\"dotted tall\">
\t\t\t\t\t\t\t\t\t\t\t<form action =\"../da/changepw\" method = \"post\" name = \"c\">
\t\t\t\t\t\t\t\t\t\t\t<div onclick =\"document.forms['c'].submit();\" style =\"cursor : pointer;\">
\t\t\t\t\t\t\t\t\t\t\t<h4>Password Change</h4>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t</form>
\t\t\t\t\t\t\t\t\t\t\t<hr>
\t\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t\t<form action =\"../da/deregistration\" method = \"post\" name = \"d\">
\t\t\t\t\t\t\t\t\t\t\t<div onclick =\"document.forms['d'].submit();\" style =\"cursor : pointer;\">
\t\t\t\t\t\t\t\t\t\t\t<h4>Deregistration</h4>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t</form>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</p>\t\t\t\t
\t\t\t\t\t</div>


\t\t\t\t\t<!-- end: page -->
\t\t\t\t</section>
\t\t\t</div>

\t\t\t
\t\t</section>

\t\t<!-- Vendor -->
\t\t<script src=\"../assets/vendor/jquery/jquery.js\"></script>
\t\t<script src=\"../assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js\"></script>
\t\t<script src=\"../assets/vendor/bootstrap/js/bootstrap.js\"></script>
\t\t<script src=\"../assets/vendor/nanoscroller/nanoscroller.js\"></script>
\t\t<script src=\"../assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js\"></script>
\t\t<script src=\"../assets/vendor/magnific-popup/magnific-popup.js\"></script>
\t\t<script src=\"../assets/vendor/jquery-placeholder/jquery.placeholder.js\"></script>
\t\t
\t\t<!-- Specific Page Vendor -->
\t\t<script src=\"../assets/vendor/jquery-autosize/jquery.autosize.js\"></script>
\t\t
\t\t<!-- Theme Base, Components and Settings -->
\t\t<script src=\"../assets/javascripts/theme.js\"></script>
\t\t
\t\t<!-- Theme Custom -->
\t\t<script src=\"../assets/javascripts/theme.custom.js\"></script>
\t\t
\t\t<!-- Theme Initialization Files -->
\t\t<script src=\"../assets/javascripts/theme.init.js\"></script>

\t</body>
</html>";
    }

    public function getTemplateName()
    {
        return "pages-user-profile.phtml";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
/* <!doctype html>*/
/* <html class="fixed">*/
/* 	<head>*/
/* */
/* 		<!-- Basic -->*/
/* 		<meta charset="UTF-8">*/
/* */
/* 		<title>User Profile</title>*/
/* 		<meta name="keywords" content="HTML5 Admin Template" />*/
/* 		<meta name="description" content="Porto Admin - Responsive HTML5 Template">*/
/* 		<meta name="author" content="okler.net">*/
/* */
/* 		<!-- Mobile Metas -->*/
/* 		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />*/
/* */
/* 		<!-- Web Fonts  -->*/
/* 		<link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">*/
/* */
/* 		<!-- Vendor CSS -->*/
/* 		<link rel="stylesheet" href="../assets/vendor/bootstrap/css/bootstrap.css" />*/
/* 		<link rel="stylesheet" href="../assets/vendor/font-awesome/css/font-awesome.css" />*/
/* 		<link rel="stylesheet" href="../assets/vendor/magnific-popup/magnific-popup.css" />*/
/* 		<link rel="stylesheet" href="../assets/vendor/bootstrap-datepicker/css/datepicker3.css" />*/
/* */
/* 		<!-- Theme CSS -->*/
/* 		<link rel="stylesheet" href="../assets/stylesheets/theme.css" />*/
/* */
/* 		<!-- Skin CSS -->*/
/* 		<link rel="stylesheet" href="../assets/stylesheets/skins/default.css" />*/
/* */
/* 		<!-- Theme Custom CSS -->*/
/* 		<link rel="stylesheet" href="../assets/stylesheets/theme-custom.css">*/
/* */
/* 		<!-- Head Libs -->*/
/* 		<script src="../assets/vendor/modernizr/modernizr.js"></script>*/
/* */
/* 	</head>*/
/* 	<body>*/
/* 		<section class="body">*/
/* */
/* 			<!-- start: header -->*/
/* 			<header class="header">*/
/* 				<div class="logo-container">*/
/* 					<form action ="../da" method = "post" name = "j">*/
/* 					<div onclick ="document.forms['j'].submit();" style ="cursor : pointer;">*/
/* 					<a class="logo">*/
/* 						<img src="../assets/images/longlogo.png" height="70" alt="JSOFT Admin" />*/
/* 					</a>*/
/* 					</div>*/
/* 					</form>*/
/* 					<div class="visible-xs toggle-sidebar-left" data-toggle-class="sidebar-left-opened" data-target="html" data-fire-event="sidebar-left-opened">*/
/* 						<i class="fa fa-bars" aria-label="Toggle sidebar"></i>*/
/* 					</div>*/
/* 				</div>*/
/* 			*/
/* 				<!-- start: search & user box -->*/
/* 				<div class="header-right">*/
/* 			*/
/* 					<form action="pages-search-results.html" class="search nav-form">*/
/* 						<div class="input-group input-search">*/
/* 							<input type="text" class="form-control" name="q" id="q" placeholder="Search...">*/
/* 							<span class="input-group-btn">*/
/* 								<button class="btn btn-default" type="submit"><i class="fa fa-search"></i></button>*/
/* 							</span>*/
/* 						</div>*/
/* 					</form>*/
/* 			*/
/* 					<span class="separator"></span>*/
/* 			*/
/* 					<div id="userbox" class="userbox">*/
/* 						<a href="#" data-toggle="dropdown">*/
/* 							<figure class="profile-picture">*/
/* 								<img src="../assets/images/!logged-user.jpg" alt="Joey" class="img-circle" data-lock-picture="../assets/images/!logged-user.jpg" />*/
/* 							</figure>*/
/* 							<div class="profile-info" data-lock-name="John Doe" data-lock-email="johndoe@JSOFT.com">*/
/* 								<span class="name">Joey</span>*/
/* 								<span class="role">administrator</span>*/
/* 							</div>*/
/* 						</a>*/
/* 					</div>*/
/* 				</div>*/
/* 				<!-- end: search & user box -->*/
/* 			</header>*/
/* 			<!-- end: header -->*/
/* */
/* 			<div class="inner-wrapper">*/
/* 				<!-- start: sidebar -->*/
/* 				<aside id="sidebar-left" class="sidebar-left">*/
/* 				*/
/* 					<div class="sidebar-header">*/
/* 						<div class="sidebar-title">*/
/* 						MENU*/
/* 						</div>*/
/* 						<div class="sidebar-toggle hidden-xs" data-toggle-class="sidebar-left-collapsed" data-target="html" data-fire-event="sidebar-left-toggle">*/
/* 							<i class="fa fa-bars" aria-label="Toggle sidebar"></i>*/
/* 						</div>*/
/* 					</div>*/
/* 				*/
/* 					<div class="nano">*/
/* 						<div class="nano-content">*/
/* 							<nav id="menu" class="nav-main" role="navigation">*/
/* 								<ul class="nav nav-main">*/
/* 									<li class="nav-active">*/
/* 									<form action ="../da" method = "post" name = "r">*/
/* 									<div onclick ="document.forms['r'].submit();" style ="cursor : pointer;">*/
/* 											<Br>&nbsp;&nbsp;&nbsp;<i class="fa fa-home" aria-hidden="true"></i>*/
/* 											<span>Home</span>*/
/* 									</div>*/
/* 									</form>	*/
/* 									</li>*/
/* 									*/
/* 									<li class="nav-active">*/
/* 										<a href="../da/temp">*/
/* 											<span>Temperature</span>*/
/* 										</a>*/
/* 									</li>*/
/* 									*/
/* 									<li class="nav-active">*/
/* 										<a href="../da/hr">*/
/* 											<span>Heart Rate</span>*/
/* 										</a>*/
/* 									</li>*/
/* 									*/
/* 									<li class="nav-active">*/
/* 										<a href="../da/air">*/
/* 											<span>Air Quality</span>*/
/* 										</a>*/
/* 									</li>*/
/* */
/* 									<li>*/
/* 										<a href="../da/profile">*/
/* 											<span class="pull-right label label-primary"></span>*/
/* 											<span>User Profile</span>*/
/* 										</a>*/
/* 									</li>*/
/* 									*/
/* 									<li class="nav-active">*/
/* 									<form action ="../da/signin" method = "post" name = "r">*/
/* 									<div onclick ="document.forms['r'].submit();" style ="cursor : pointer;">*/
/* 											<span class="pull-right label label-primary"></span>*/
/* 											<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sign Out</span>*/
/* 									</div>*/
/* 									</form>*/
/* 									</li>*/
/* 								</ul>	*/
/* 						</div>*/
/* 					</div>*/
/* 				</aside>*/
/* 			*/
/* 				<!-- end: sidebar -->*/
/* */
/* 				<section role="main" class="content-body">*/
/* 					<header class="page-header">*/
/* 						<h2>User Profile</h2>*/
/* 					*/
/* 						<div class="right-wrapper pull-right">*/
/* 							<ol class="breadcrumbs">*/
/* 								<li>*/
/* 									<a href="index.html">*/
/* 										<i class="fa fa-home"></i>*/
/* 									</a>*/
/* 								</li>*/
/* 								<li><span>Pages</span></li>*/
/* 								<li><span>User Profile</span></li>*/
/* 							</ol>*/
/* 					*/
/* 							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>*/
/* 						</div>*/
/* 					</header>*/
/* */
/* 					<!-- start: page -->*/
/* */
/* 					<div class="row">*/
/* 					<p style="text-align: center;">*/
/* 						<div class="col-md-8 col-lg-6">*/
/* 						<div style =  margint-left: auto; margin-right: auto;>*/
/* */
/* 							<div class="tabs">*/
/* 								<ul class="nav nav-tabs tabs-primary">*/
/* 									<li class="active">*/
/* 										<a href="#overview" data-toggle="tab">My profile</a>*/
/* 									</li>*/
/* 								</ul>*/
/* 								<div class="tab-content">*/
/* 									<div id="overview" class="tab-pane active">*/
/* 										<h4 class="mb-md"></h4>*/
/* 										*/
/* 											<h5> E-mail </h5>*/
/* 											<hr color ="black">*/
/* 											<h5> First Name</h5>*/
/* 											<hr color ="black">*/
/* 											<h5> Last Name</h5>*/
/* 											<hr color ="black">*/
/* 											<h5> Gender </h5>*/
/* 											<hr color ="black">*/
/* 											*/
/* 											<hr class="dotted tall">*/
/* 											<form action ="../da/changepw" method = "post" name = "c">*/
/* 											<div onclick ="document.forms['c'].submit();" style ="cursor : pointer;">*/
/* 											<h4>Password Change</h4>*/
/* 											</div>*/
/* 											</form>*/
/* 											<hr>*/
/* 											*/
/* 											<form action ="../da/deregistration" method = "post" name = "d">*/
/* 											<div onclick ="document.forms['d'].submit();" style ="cursor : pointer;">*/
/* 											<h4>Deregistration</h4>*/
/* 											</div>*/
/* 											</form>*/
/* 									</div>*/
/* 								</div>*/
/* 							</div>*/
/* 						</div>*/
/* 						</div>*/
/* 					</p>				*/
/* 					</div>*/
/* */
/* */
/* 					<!-- end: page -->*/
/* 				</section>*/
/* 			</div>*/
/* */
/* 			*/
/* 		</section>*/
/* */
/* 		<!-- Vendor -->*/
/* 		<script src="../assets/vendor/jquery/jquery.js"></script>*/
/* 		<script src="../assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>*/
/* 		<script src="../assets/vendor/bootstrap/js/bootstrap.js"></script>*/
/* 		<script src="../assets/vendor/nanoscroller/nanoscroller.js"></script>*/
/* 		<script src="../assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>*/
/* 		<script src="../assets/vendor/magnific-popup/magnific-popup.js"></script>*/
/* 		<script src="../assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>*/
/* 		*/
/* 		<!-- Specific Page Vendor -->*/
/* 		<script src="../assets/vendor/jquery-autosize/jquery.autosize.js"></script>*/
/* 		*/
/* 		<!-- Theme Base, Components and Settings -->*/
/* 		<script src="../assets/javascripts/theme.js"></script>*/
/* 		*/
/* 		<!-- Theme Custom -->*/
/* 		<script src="../assets/javascripts/theme.custom.js"></script>*/
/* 		*/
/* 		<!-- Theme Initialization Files -->*/
/* 		<script src="../assets/javascripts/theme.init.js"></script>*/
/* */
/* 	</body>*/
/* </html>*/
