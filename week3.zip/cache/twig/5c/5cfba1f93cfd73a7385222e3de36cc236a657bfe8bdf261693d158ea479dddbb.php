<?php

/* process_good.phtml */
class __TwigTemplate_2ba48bc65e0e5f5b984ab261ae1f16d9cc2798a20092be4ce23f4bf7bdbd8b91 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<html>
    <head>
        <meta charset=\"utf-8\"/>
        <title>Slim 3</title>
        <link href='//fonts.googleapis.com/css?family=Lato:300' rel='stylesheet' type='text/css'>
        <link href='";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('slim')->baseUrl(), "html", null, true);
        echo "/css/style.css' rel='stylesheet' type='text/css'>
    </head>
    <body>
     <?php echo \$myarray['yourname'].; ?>
\t Hello. Thank you for registeration!
\t
\t </body>
</html>
        
";
    }

    public function getTemplateName()
    {
        return "process_good.phtml";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  26 => 6,  19 => 1,);
    }
}
/* <html>*/
/*     <head>*/
/*         <meta charset="utf-8"/>*/
/*         <title>Slim 3</title>*/
/*         <link href='//fonts.googleapis.com/css?family=Lato:300' rel='stylesheet' type='text/css'>*/
/*         <link href='{{ base_url() }}/css/style.css' rel='stylesheet' type='text/css'>*/
/*     </head>*/
/*     <body>*/
/*      <?php echo $myarray['yourname'].; ?>*/
/* 	 Hello. Thank you for registeration!*/
/* 	*/
/* 	 </body>*/
/* </html>*/
/*         */
/* */
