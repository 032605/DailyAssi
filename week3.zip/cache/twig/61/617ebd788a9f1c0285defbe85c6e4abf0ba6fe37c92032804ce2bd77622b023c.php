<?php

/* register.phtml */
class __TwigTemplate_5d390965ab17dd79642d7458209c23be6d5acb4674f6e399434216edb73206e5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!doctype html>
<html class=\"fixed\">
\t<head>

\t\t<!-- Basic -->
\t\t<meta charset=\"UTF-8\">

\t\t<meta name=\"keywords\" content=\"HTML5 Admin Template\" />
\t\t<meta name=\"description\" content=\"Porto Admin - Responsive HTML5 Template\">
\t\t<meta name=\"author\" content=\"okler.net\">

\t\t<!-- Mobile Metas -->
\t\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no\" />

\t\t<!-- Web Fonts  -->
\t\t<link href=\"http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light\" rel=\"stylesheet\" type=\"text/css\">

\t\t<!-- Vendor CSS -->
\t\t<link rel=\"stylesheet\" href=\"../assets/vendor/bootstrap/css/bootstrap.css\" />
\t\t<link rel=\"stylesheet\" href=\"../assets/vendor/font-awesome/css/font-awesome.css\" />
\t\t<link rel=\"stylesheet\" href=\"../assets/vendor/magnific-popup/magnific-popup.css\" />
\t\t<link rel=\"stylesheet\" href=\"../assets/vendor/bootstrap-datepicker/css/datepicker3.css\" />

\t\t<!-- Theme CSS -->
\t\t<link rel=\"stylesheet\" href=\"../assets/stylesheets/theme.css\" />

\t\t<!-- Skin CSS -->
\t\t<link rel=\"stylesheet\" href=\"../assets/stylesheets/skins/default.css\" />

\t\t<!-- Theme Custom CSS -->
\t\t<link rel=\"stylesheet\" href=\"../assets/stylesheets/theme-custom.css\">

\t\t<!-- Head Libs -->
\t\t<script src=\"../assets/vendor/modernizr/modernizr.js\"></script>

\t</head>
\t<body>
\t\t<!-- start: page -->
\t\t<section class=\"body-sign\">
\t\t\t<div class=\"center-sign\">
\t\t\t\t<a href=\"/\" class=\"logo pull-left\">
\t\t\t\t\t<img src=\"../assets/images/glogo.png\" weight =\"80\" height=\"70\" alt=\"Porto Admin\" />
\t\t\t\t</a>

\t\t\t\t<div class=\"panel panel-sign\">
\t\t\t\t\t<div class=\"panel-title-sign mt-xl text-right\">
\t\t\t\t\t\t<h2 class=\"title text-uppercase text-bold m-none\"><i class=\"fa fa-user mr-xs\"></i> Sign Up</h2>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"panel-body\">
\t\t\t\t\t\t<form method = \"post\" action = \"process\">
\t\t\t\t\t\t\t
\t\t\t\t\t\t\t<div class=\"col-sm-6 mb-lg\">
\t\t\t\t\t\t\t\t\t\t<label>First Name</label>
\t\t\t\t\t\t\t\t\t\t<input name=\"pwd_confirm\" type=\"password\" class=\"form-control input-lg\" />
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t    <div class=\"col-sm-6 mb-lg\">
\t\t\t\t\t\t\t\t\t\t<label>Last Name</label>
\t\t\t\t\t\t\t\t\t\t<input name=\"pwd_confirm\" type=\"password\" class=\"form-control input-lg\" />
\t\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t<div class=\"form-group mb-lg\">
\t\t\t\t\t\t\t\t<label>E-mail Address</label>
\t\t\t\t\t\t\t\t<input name=\"email\" type=\"email\" class=\"form-control input-lg\" />
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t<div class=\"form-group mb-none\">
\t\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t\t<div class=\"col-sm-6 mb-lg\">
\t\t\t\t\t\t\t\t\t\t<label>Password</label>
\t\t\t\t\t\t\t\t\t\t<input name=\"pwd\" type=\"password\" class=\"form-control input-lg\" />
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"col-sm-6 mb-lg\">
\t\t\t\t\t\t\t\t\t\t<label>Password Confirmation</label>
\t\t\t\t\t\t\t\t\t\t<input name=\"pwd_confirm\" type=\"password\" class=\"form-control input-lg\" />
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t<div class=\"form-group mb-lg\">
\t\t\t\t\t\t\t\t<label>Gender</label>
\t\t\t\t\t\t\t\t<select>
\t\t\t\t\t\t\t\t<option value = \"male\"> male </option>
\t\t\t\t\t\t\t\t<option value = \"female\"> female </option>
\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t</div>
\t\t\t\t<div>
\t\t\t\t<input type =\"submit\" value = \"sign up!\">
\t\t\t\t<p class=\"text-center\">Already have an account? <a href=\"pages-signin.html\">Sign In!</a>
\t\t\t\t<p class=\"text-center\">Don't you remember password? <a href=\"pages-forgttenpassword.html\">click</a>
\t\t\t\t\t\t</form>
\t\t\t\t\t</div>
\t\t\t\t</div>

\t\t\t\t<p class=\"text-center text-muted mt-md mb-md\">&copy; Copyright 2018. All rights reserved. Template by <a href=\"https://colorlib.com\">Colorlib</a>.</p>
\t\t\t</div>
\t\t</section>
\t\t<!-- end: page -->

\t\t<!-- Vendor -->
\t\t<script src=\"../assets/vendor/jquery/jquery.js\"></script>
\t\t<script src=\"../assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js\"></script>
\t\t<script src=\"../assets/vendor/bootstrap/js/bootstrap.js\"></script>
\t\t<script src=\"../assets/vendor/nanoscroller/nanoscroller.js\"></script>
\t\t<script src=\"../assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js\"></script>
\t\t<script src=\"../assets/vendor/magnific-popup/magnific-popup.js\"></script>
\t\t<script src=\"../assets/vendor/jquery-placeholder/jquery.placeholder.js\"></script>
\t\t
\t\t<!-- Theme Base, Components and Settings -->
\t\t<script src=\"../assets/javascripts/theme.js\"></script>
\t\t
\t\t<!-- Theme Custom -->
\t\t<script src=\"../assets/javascripts/theme.custom.js\"></script>
\t\t
\t\t<!-- Theme Initialization Files -->
\t\t<script src=\"../assets/javascripts/theme.init.js\"></script>

\t</body>
</html>";
    }

    public function getTemplateName()
    {
        return "register.phtml";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
/* <!doctype html>*/
/* <html class="fixed">*/
/* 	<head>*/
/* */
/* 		<!-- Basic -->*/
/* 		<meta charset="UTF-8">*/
/* */
/* 		<meta name="keywords" content="HTML5 Admin Template" />*/
/* 		<meta name="description" content="Porto Admin - Responsive HTML5 Template">*/
/* 		<meta name="author" content="okler.net">*/
/* */
/* 		<!-- Mobile Metas -->*/
/* 		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />*/
/* */
/* 		<!-- Web Fonts  -->*/
/* 		<link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">*/
/* */
/* 		<!-- Vendor CSS -->*/
/* 		<link rel="stylesheet" href="../assets/vendor/bootstrap/css/bootstrap.css" />*/
/* 		<link rel="stylesheet" href="../assets/vendor/font-awesome/css/font-awesome.css" />*/
/* 		<link rel="stylesheet" href="../assets/vendor/magnific-popup/magnific-popup.css" />*/
/* 		<link rel="stylesheet" href="../assets/vendor/bootstrap-datepicker/css/datepicker3.css" />*/
/* */
/* 		<!-- Theme CSS -->*/
/* 		<link rel="stylesheet" href="../assets/stylesheets/theme.css" />*/
/* */
/* 		<!-- Skin CSS -->*/
/* 		<link rel="stylesheet" href="../assets/stylesheets/skins/default.css" />*/
/* */
/* 		<!-- Theme Custom CSS -->*/
/* 		<link rel="stylesheet" href="../assets/stylesheets/theme-custom.css">*/
/* */
/* 		<!-- Head Libs -->*/
/* 		<script src="../assets/vendor/modernizr/modernizr.js"></script>*/
/* */
/* 	</head>*/
/* 	<body>*/
/* 		<!-- start: page -->*/
/* 		<section class="body-sign">*/
/* 			<div class="center-sign">*/
/* 				<a href="/" class="logo pull-left">*/
/* 					<img src="../assets/images/glogo.png" weight ="80" height="70" alt="Porto Admin" />*/
/* 				</a>*/
/* */
/* 				<div class="panel panel-sign">*/
/* 					<div class="panel-title-sign mt-xl text-right">*/
/* 						<h2 class="title text-uppercase text-bold m-none"><i class="fa fa-user mr-xs"></i> Sign Up</h2>*/
/* 					</div>*/
/* 					<div class="panel-body">*/
/* 						<form method = "post" action = "process">*/
/* 							*/
/* 							<div class="col-sm-6 mb-lg">*/
/* 										<label>First Name</label>*/
/* 										<input name="pwd_confirm" type="password" class="form-control input-lg" />*/
/* 									</div>*/
/* 									*/
/* 						    <div class="col-sm-6 mb-lg">*/
/* 										<label>Last Name</label>*/
/* 										<input name="pwd_confirm" type="password" class="form-control input-lg" />*/
/* 									</div>*/
/* */
/* 							<div class="form-group mb-lg">*/
/* 								<label>E-mail Address</label>*/
/* 								<input name="email" type="email" class="form-control input-lg" />*/
/* 							</div>*/
/* */
/* 							<div class="form-group mb-none">*/
/* 								<div class="row">*/
/* 									<div class="col-sm-6 mb-lg">*/
/* 										<label>Password</label>*/
/* 										<input name="pwd" type="password" class="form-control input-lg" />*/
/* 									</div>*/
/* 									<div class="col-sm-6 mb-lg">*/
/* 										<label>Password Confirmation</label>*/
/* 										<input name="pwd_confirm" type="password" class="form-control input-lg" />*/
/* 									</div>*/
/* 								*/
/* 									<div class="form-group mb-lg">*/
/* 								<label>Gender</label>*/
/* 								<select>*/
/* 								<option value = "male"> male </option>*/
/* 								<option value = "female"> female </option>*/
/* 								</select>*/
/* 							</div>*/
/* 				<div>*/
/* 				<input type ="submit" value = "sign up!">*/
/* 				<p class="text-center">Already have an account? <a href="pages-signin.html">Sign In!</a>*/
/* 				<p class="text-center">Don't you remember password? <a href="pages-forgttenpassword.html">click</a>*/
/* 						</form>*/
/* 					</div>*/
/* 				</div>*/
/* */
/* 				<p class="text-center text-muted mt-md mb-md">&copy; Copyright 2018. All rights reserved. Template by <a href="https://colorlib.com">Colorlib</a>.</p>*/
/* 			</div>*/
/* 		</section>*/
/* 		<!-- end: page -->*/
/* */
/* 		<!-- Vendor -->*/
/* 		<script src="../assets/vendor/jquery/jquery.js"></script>*/
/* 		<script src="../assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>*/
/* 		<script src="../assets/vendor/bootstrap/js/bootstrap.js"></script>*/
/* 		<script src="../assets/vendor/nanoscroller/nanoscroller.js"></script>*/
/* 		<script src="../assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>*/
/* 		<script src="../assets/vendor/magnific-popup/magnific-popup.js"></script>*/
/* 		<script src="../assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>*/
/* 		*/
/* 		<!-- Theme Base, Components and Settings -->*/
/* 		<script src="../assets/javascripts/theme.js"></script>*/
/* 		*/
/* 		<!-- Theme Custom -->*/
/* 		<script src="../assets/javascripts/theme.custom.js"></script>*/
/* 		*/
/* 		<!-- Theme Initialization Files -->*/
/* 		<script src="../assets/javascripts/theme.init.js"></script>*/
/* */
/* 	</body>*/
/* </html>*/
