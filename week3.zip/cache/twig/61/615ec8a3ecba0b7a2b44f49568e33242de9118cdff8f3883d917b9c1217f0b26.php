<?php

/* post.twig */
class __TwigTemplate_c0adfd1659cf34d95fb548a3a57e69c2d1f84ce64f395bf3563caa4c8e7a4696 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<html>
<head>
    <meta charset=\"utf-8\"/>
    <title>Slim 3</title>
    <link href='//fonts.googleapis.com/css?family=Lato:300' rel='stylesheet' type='text/css'>
    <link href='";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('slim')->baseUrl(), "html", null, true);
        echo "/css/style.css' rel='stylesheet' type='text/css'>
</head>
<body>
<h1>Slim</h1>
<div>a microframework for PHP</div>

";
        // line 12
        if ((isset($context["flash"]) ? $context["flash"] : null)) {
            // line 13
            echo "<div style=\"margin:30px auto;\">
    ";
            // line 14
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["flash"]) ? $context["flash"] : null));
            foreach ($context['_seq'] as $context["_key"] => $context["f"]) {
                // line 15
                echo "        <p>";
                echo twig_escape_filter($this->env, $context["f"], "html", null, true);
                echo "</p>
    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['f'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 17
            echo "</div>
";
        }
        // line 19
        echo "
<div style=\"margin-top: 30px\">
    ";
        // line 21
        if ((isset($context["post"]) ? $context["post"] : null)) {
            // line 22
            echo "        <h2>";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : null), "title", array()), "html", null, true);
            echo "</h2>
        <hr>
        <p>";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : null), "content", array()), "html", null, true);
            echo "</p>
    ";
        }
        // line 26
        echo "</div>
</body>
</html>";
    }

    public function getTemplateName()
    {
        return "post.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  74 => 26,  69 => 24,  63 => 22,  61 => 21,  57 => 19,  53 => 17,  44 => 15,  40 => 14,  37 => 13,  35 => 12,  26 => 6,  19 => 1,);
    }
}
/* <html>*/
/* <head>*/
/*     <meta charset="utf-8"/>*/
/*     <title>Slim 3</title>*/
/*     <link href='//fonts.googleapis.com/css?family=Lato:300' rel='stylesheet' type='text/css'>*/
/*     <link href='{{ base_url() }}/css/style.css' rel='stylesheet' type='text/css'>*/
/* </head>*/
/* <body>*/
/* <h1>Slim</h1>*/
/* <div>a microframework for PHP</div>*/
/* */
/* {% if flash %}*/
/* <div style="margin:30px auto;">*/
/*     {% for f in flash %}*/
/*         <p>{{ f }}</p>*/
/*     {% endfor %}*/
/* </div>*/
/* {% endif %}*/
/* */
/* <div style="margin-top: 30px">*/
/*     {% if post %}*/
/*         <h2>{{ post.title }}</h2>*/
/*         <hr>*/
/*         <p>{{ post.content }}</p>*/
/*     {% endif %}*/
/* </div>*/
/* </body>*/
/* </html>*/
