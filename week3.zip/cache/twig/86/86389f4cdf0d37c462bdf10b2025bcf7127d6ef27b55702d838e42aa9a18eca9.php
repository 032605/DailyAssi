<?php

/* sign-up.phtml */
class __TwigTemplate_3ac16327a74c54a3becc76d28abd8ca8b51817180257d504b3e046c8ce867cf0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!doctype html>
<html lang=\"en\">
 
<head>
    <!-- Required meta tags -->
    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">
    <title>Concept - Bootstrap 4 Admin Dashboard Template</title>
    <!-- Bootstrap CSS -->
    <link rel=\"stylesheet\" href=\"../assets/vendor/bootstrap/css/bootstrap.min.css\">
    <link href=\"../assets/vendor/fonts/circular-std/style.css\" rel=\"stylesheet\">
    <link rel=\"stylesheet\" href=\"../assets/libs/css/style.css\">
    <link rel=\"stylesheet\" href=\"../assets/vendor/fonts/fontawesome/css/fontawesome-all.css\">
    <style>
    html,
    body {
        height: 100%;
    }

    body {
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center;
        padding-top: 40px;
        padding-bottom: 40px;
    }
    </style>
</head>
<!-- ============================================================== -->
<!-- signup form  -->
<!-- ============================================================== -->

<body>
    <!-- ============================================================== -->
    <!-- signup form  -->
    <!-- ============================================================== -->
    <form class=\"splash-container\">
        <div class=\"card\">
            <div class=\"card-header\">
                <h3 class=\"mb-1\">Registrations Form</h3>
                <p>Please enter your user information.</p>
            </div>
            <div class=\"card-body\">
                <div class=\"form-group\">
                    <input class=\"form-control form-control-lg\" type=\"email\" name=\"email\" required=\"\" placeholder=\"E-mail\" autocomplete=\"off\">
                </div>
                <div class=\"form-group\">
\t\t\t\t\t<div class=\"col-sm-6 mb-lg\">
\t\t\t\t\t\t\t\t\t\t<input class=\"form-control form-control-lg\" name=\"First Name\" type=\"name\" placeholder=\"First Name\"/>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"col-sm-6 mb-lg\">
\t\t\t\t\t\t\t\t\t\t<input class=\"form-control form-control-lg\" name=\"Last Name\" type=\"name\" placeholder=\"Last Name\" />
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t</div>
                <div class=\"form-group\">
                    <input class=\"form-control form-control-lg\" id=\"pass1\" type=\"password\" required=\"\" placeholder=\"Password\">
                </div>
                <div class=\"form-group\">
                    <input class=\"form-control form-control-lg\" required=\"\" placeholder=\"Confirm Password\" type=\"password\">
                </div>
\t\t\t\t<div class =\"form-group\">
\t\t\t\t\t<label class=\"custom-control custom-radiobutton\">Gender
\t\t\t\t\t\t<input type=\"radio\" name=\"gender\" value=\"m\"/>남
\t\t\t\t\t\t<input type=\"radio\" name=\"gender\" value=\"f\"/>여
\t\t\t\t\t</label>\t\t
\t\t\t\t</div>
                <div class=\"form-group pt-2\">
                    <button class=\"btn btn-block btn-primary\" type=\"submit\">Register My Account</button>
                </div>
                <div class=\"form-group\">
                    <label class=\"custom-control custom-checkbox\">
                        <input class=\"custom-control-input\" type=\"checkbox\"><span class=\"custom-control-label\">By creating an account, you agree the <a href=\"#\">terms and conditions</a></span>
                    </label>
                </div>
            </div>
            <div class=\"card-footer bg-white\">
\t\t\t\t<p class=\"text-center\">Already have an account? <a href=\"pages-signin.html\">Sign In!</a>
            </div>
        </div>
    </form>
</body>

 
</html>";
    }

    public function getTemplateName()
    {
        return "sign-up.phtml";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
/* <!doctype html>*/
/* <html lang="en">*/
/*  */
/* <head>*/
/*     <!-- Required meta tags -->*/
/*     <meta charset="utf-8">*/
/*     <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">*/
/*     <title>Concept - Bootstrap 4 Admin Dashboard Template</title>*/
/*     <!-- Bootstrap CSS -->*/
/*     <link rel="stylesheet" href="../assets/vendor/bootstrap/css/bootstrap.min.css">*/
/*     <link href="../assets/vendor/fonts/circular-std/style.css" rel="stylesheet">*/
/*     <link rel="stylesheet" href="../assets/libs/css/style.css">*/
/*     <link rel="stylesheet" href="../assets/vendor/fonts/fontawesome/css/fontawesome-all.css">*/
/*     <style>*/
/*     html,*/
/*     body {*/
/*         height: 100%;*/
/*     }*/
/* */
/*     body {*/
/*         display: -ms-flexbox;*/
/*         display: flex;*/
/*         -ms-flex-align: center;*/
/*         align-items: center;*/
/*         padding-top: 40px;*/
/*         padding-bottom: 40px;*/
/*     }*/
/*     </style>*/
/* </head>*/
/* <!-- ============================================================== -->*/
/* <!-- signup form  -->*/
/* <!-- ============================================================== -->*/
/* */
/* <body>*/
/*     <!-- ============================================================== -->*/
/*     <!-- signup form  -->*/
/*     <!-- ============================================================== -->*/
/*     <form class="splash-container">*/
/*         <div class="card">*/
/*             <div class="card-header">*/
/*                 <h3 class="mb-1">Registrations Form</h3>*/
/*                 <p>Please enter your user information.</p>*/
/*             </div>*/
/*             <div class="card-body">*/
/*                 <div class="form-group">*/
/*                     <input class="form-control form-control-lg" type="email" name="email" required="" placeholder="E-mail" autocomplete="off">*/
/*                 </div>*/
/*                 <div class="form-group">*/
/* 					<div class="col-sm-6 mb-lg">*/
/* 										<input class="form-control form-control-lg" name="First Name" type="name" placeholder="First Name"/>*/
/* 									</div>*/
/* 					<div class="col-sm-6 mb-lg">*/
/* 										<input class="form-control form-control-lg" name="Last Name" type="name" placeholder="Last Name" />*/
/* 									</div>*/
/* 				</div>*/
/*                 <div class="form-group">*/
/*                     <input class="form-control form-control-lg" id="pass1" type="password" required="" placeholder="Password">*/
/*                 </div>*/
/*                 <div class="form-group">*/
/*                     <input class="form-control form-control-lg" required="" placeholder="Confirm Password" type="password">*/
/*                 </div>*/
/* 				<div class ="form-group">*/
/* 					<label class="custom-control custom-radiobutton">Gender*/
/* 						<input type="radio" name="gender" value="m"/>남*/
/* 						<input type="radio" name="gender" value="f"/>여*/
/* 					</label>		*/
/* 				</div>*/
/*                 <div class="form-group pt-2">*/
/*                     <button class="btn btn-block btn-primary" type="submit">Register My Account</button>*/
/*                 </div>*/
/*                 <div class="form-group">*/
/*                     <label class="custom-control custom-checkbox">*/
/*                         <input class="custom-control-input" type="checkbox"><span class="custom-control-label">By creating an account, you agree the <a href="#">terms and conditions</a></span>*/
/*                     </label>*/
/*                 </div>*/
/*             </div>*/
/*             <div class="card-footer bg-white">*/
/* 				<p class="text-center">Already have an account? <a href="pages-signin.html">Sign In!</a>*/
/*             </div>*/
/*         </div>*/
/*     </form>*/
/* </body>*/
/* */
/*  */
/* </html>*/
