<?php

/* home.phtml */
class __TwigTemplate_2c8ee1325054533fc932e2a0b00defc6377cb6ba120f6152161c647c37303055 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<html>
    <head>
        <meta charset=\"utf-8\"/>
        <title>Daily Assi.</title>
        <link href='//fonts.googleapis.com/css?family=Lato:300' rel='stylesheet' type='text/css'>
        <link href='";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('slim')->baseUrl(), "html", null, true);
        echo "/css/style.css' rel='stylesheet' type='text/css'>
    </head>
    <body>
\t\t<br>
\t\t<br>
\t\t<br>
\t\t<br>
\t\t<br>
\t\t<br>
\t\t
\t\t\t<form action=\"../da/signin\" name=\"da02\" method=\"post\">
\t\t\t\t<div onclick = \"document.forms ['da02'].submit();\" style = \"cursor : pointer;\">\t\t\t
\t\t\t\t\t<p style=\"text-align: center;\">
\t\t\t\t\t<a> <img src=\"../assets/images/mainlogo.png\" width=\"400\"  height=\"400\"> </a>
\t\t\t\t\t</p>
\t\t\t\t</div>
\t\t\t</form>
    </body>
</html>
        
";
    }

    public function getTemplateName()
    {
        return "home.phtml";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  26 => 6,  19 => 1,);
    }
}
/* <html>*/
/*     <head>*/
/*         <meta charset="utf-8"/>*/
/*         <title>Daily Assi.</title>*/
/*         <link href='//fonts.googleapis.com/css?family=Lato:300' rel='stylesheet' type='text/css'>*/
/*         <link href='{{ base_url() }}/css/style.css' rel='stylesheet' type='text/css'>*/
/*     </head>*/
/*     <body>*/
/* 		<br>*/
/* 		<br>*/
/* 		<br>*/
/* 		<br>*/
/* 		<br>*/
/* 		<br>*/
/* 		*/
/* 			<form action="../da/signin" name="da02" method="post">*/
/* 				<div onclick = "document.forms ['da02'].submit();" style = "cursor : pointer;">			*/
/* 					<p style="text-align: center;">*/
/* 					<a> <img src="../assets/images/mainlogo.png" width="400"  height="400"> </a>*/
/* 					</p>*/
/* 				</div>*/
/* 			</form>*/
/*     </body>*/
/* </html>*/
/*         */
/* */
